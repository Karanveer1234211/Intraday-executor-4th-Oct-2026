# Intraday Project — starting state (11 Oct 2026)

## What already exists and runs
| File | Status | What it does |
|---|---|---|
| intraday_cache.py v1.7 | tests pass | Kite 3-minute bars for stocks + NIFTY 50, NIFTY BANK, NIFTY IT. `--symbols-file` now fills holes. |
| bigmove_study.py v1.1 | run 11 Oct 2026: DEAD (see below) | Opening-range breakout study; v2 imports its helpers. |
| bigmove2_study.py v1 | full suite VERIFIED (718 s, exit 0), NOT yet run on real data | 8 families x long/short: NIFTY trap-and-snap, kinetic slingshot pullback, late coil break; stock trap reversal, breakout retest, late coil, exhaustion fade, 10:30 relative-strength leader. Plus gates (market state, BANK/IT sync, sector, breadth, RVOL) and exits (pyramid adds, EMA/SuperTrend trails). |
| BIGMOVE2_DECLARATION.json | fingerprint 5f6f3515353f593a | Rules and settings for v2, frozen. |

Test results worth knowing: on 6 null (no-edge) markets with costs, 0 of 96 family-sides came out PROMISING; planted edges were found in every family.

## Run it (Windows cmd)
All research code lives in `bigmove_deploy\open_close\` (it needs stage_b_screen.py and research_common.py from there). `env_daily.bat` stays in `bigmove_deploy\`.

```
cd /d C:\Users\karanvsi\PyCharmMiscProject\bigmove_deploy
call env_daily.bat
cd open_close
python intraday_cache.py update --root %CACHE_DAILY_ROOT% --symbols-file indices.txt
python bigmove2_study.py --root %CACHE_DAILY_ROOT% --coverage-only
python bigmove2_study.py --root %CACHE_DAILY_ROOT% --allow-partial-universe
```
Output: `%CACHE_DAILY_ROOT%\research2\bigmove2\BM2_<date>_<n>\report.md`.

## BIGMOVE v1.1 result (run 11 Oct 2026): DEAD
Opening-range breakouts: longs -12.3 [-19.1, -5.6] bp/day discovery, -12.4 [-19.7, -4.8] confirmation; buying every breakout -10.8; random picks lose the same. Shorts best +2.7 [-2.6, +7.9] discovery, -2.4 [-8.8, +4.1] confirmation (WATCH, p search 0.090). NIFTY sleeve nothing. Useful: VWAP exit on longs added +9.2 [+4.8, +13.5] disc, +7.0 [+1.5, +12.6] conf.

## Lessons carried over
- Entry at the next bar's open, never the signal bar's close.
- Costs kill thin intraday edges: plan on ~10-15 bp round trip all-in for stocks.
- A setup must beat "take every trigger" to show real selection skill.
- CAS rules from 3 Aug 2026 change MIS square-off for CAS stocks (~15:10).
