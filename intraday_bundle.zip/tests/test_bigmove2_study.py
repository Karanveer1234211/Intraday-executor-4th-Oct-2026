#!/usr/bin/env python3
"""
tests/test_bigmove2_study.py - bigmove2_study v1 (BIGMOVE v2 'LEVIATHAN'). Prints VERIFIED on success.

 1. By hand: the shared configuration with v1.1; the 40-cell grid; costs per unit (adds at their own notional) and
    net returns; the close before a bar; the index session average; EMA and SuperTrend against plain loops; time-of-day
    participation (RVOL); the coil history share and median; the 10:00 market state (TRAP / KINETIC / RANGE / NA);
    the trap rule (fresh break, snap window, wick snap, stale break); the trade engine (open entry, stop in the entry
    bar, gap stop, missing exit bar, opened beyond the stop, trail, P1 / P2 adds, the same-bar add-and-stop orders,
    shorts); the N-slot book (first come, first served, score ties, no reuse) and the exposure-matched average trigger;
    gates (judged / passed, the state before 10:00); verdicts and p (search); H6 by hand; the fixed random numbers.
 2. The trade engine against an INDEPENDENT bar-by-bar loop on random sessions with missing bars: every variant (time,
    P1, P2, EMA trail, SuperTrend trail, P1 + trail, the mirrored control) - entry, exit bar, kind, units, gross.
 3. Two implementations of every trigger rule (the study's vectorised code and the plain loops in bigmove2_world.py)
    agree exactly on every session of a world with missing bars: all 8 families, every cell, both sides.
 4. Fill fairness: on continuous driftless paths, no exit or add earns a positive mean before costs.
 5. Look-ahead: changing everything after the decision bar (and every later day) leaves every trigger, entry, stop,
    score and gate value unchanged, while outcomes change; planted leaks are caught.
 6. Planted worlds through the whole pipeline (selection, verdicts, gates, management, H2, H6) and their nulls.
 7. main() end to end with stand-in modules: coverage, refusal, outputs, index files and their price check (a wrong
    instrument is caught), missing BANK / IT, provenance and output hashes, RERUN.
 8. Selection calibration in null markets.
"""

from __future__ import annotations

import contextlib
import io
import json
import math
import shutil
import sys
import tempfile
import time
import types
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import bigmove_study as BM               # noqa: E402
import bigmove2_study as B2              # noqa: E402
import bigmove2_world as WW              # noqa: E402

FAILS = []
NB = B2.NB
B2.CFG["top_n"] = [3, 6]                 # small test worlds: slots must be scarce
B2.CELLS = B2.family_cells()


def check(cond, msg):
    print(("  ok  " if cond else "  FAIL") + f"  {msg}", flush=True)
    if not cond:
        FAILS.append(msg)


def same(a, b, tol=1e-9) -> bool:
    a, b = np.asarray(a, float), np.asarray(b, float)
    return a.shape == b.shape and bool(np.all((np.isnan(a) & np.isnan(b)) | (np.abs(a - b) <= tol * np.maximum(1.0, np.abs(a)))))


def sess(o, h, l, c, v=None):
    """One session as 1 x 125 matrices from per-bar lists."""
    B = {k: np.asarray(x, float)[None, :] for k, x in (("open", o), ("high", h), ("low", l), ("close", c))}
    B["volume"] = np.full((1, NB), 1000.0) if v is None else np.asarray(v, float)[None, :]
    return B


def flat(p=100.0, eps=0.01):
    o = np.full(NB, p)
    return o.copy(), o + eps, o - eps, o.copy()


# ----------------------------------------------------------------------
# 1. by hand
# ----------------------------------------------------------------------
def by_hand():
    print("1. by hand")
    check(B2.shared_config_problems() == [] and len(B2.cell_keys()) == 40 and B2.T_LAST == 104 and B2.XS == 116 and B2.XI == 120,
          "v1.1's frozen configuration agrees on every shared value; 40 cells per side; triggers up to bar 104, exits 15:03 / 15:15")
    ck = B2.cell_keys()
    check([k for k in ck if k[0] == "X1"][0] == ("X1", "m3|IB|div0", 0) and ("S5", "c44", 6) in ck and ("S3", "q10", 3) in ck,
          "cell names: X1 m3|IB|div0, S5 c44 N6, S3 q10 N3 (top N 3 / 6 in the tests)")
    # costs
    c1, c5, c25 = (BM.cash_cost_bps(5e5 * z) for z in (1.0, 0.5, 0.25))
    tot = B2.stock_cost_bp([np.array([1.0]), np.array([0.5]), np.array([0.25])])[0]
    check(abs(tot - (c1 + 0.5 * c5 + 0.25 * c25)) < 1e-12 and c5 > c1 and abs(B2.COST_BPS - 4.49212) < 1e-5,
          f"costs: each unit at its own notional (Rs 5 / 2.5 / 1.25 lakh: {c1:.3f} / {c5:.3f} / {c25:.3f} bp) -> {tot:.4f} bp of a base position")
    ic = B2.index_cost_bp([np.array([1.0])], np.array([24000.0]))[0]
    check(abs(ic - BM.fut_cost_bps(65 * 24000.0)) < 1e-12 and abs(B2.index_slip_bp(np.array([20000.0]))[0] - 1.0) < 1e-12,
          f"NIFTY: futures cost on one lot ({ic:.3f} bp at 24,000) and 1 point a side = 1.0 bp a round trip at 20,000")
    n_ = B2.net_of(np.array([0.01, 0.01, 0.0]), np.array([B2.KIND_TIME, B2.KIND_STOP, B2.KIND_NONE]), np.array([1.5, 1.0, 0.0]),
                   np.array([8.0, 10.0, 8.0]), np.array([6.0, 4.5, 4.5]), 1.5)
    check(same(n_, [0.01 - (1.5 * 1.5 * 8 + 6) / 1e4, 0.01 - (1.5 * 10 + 4.5) / 1e4, 0.0]),
          "net = gross - (multiplier x units x slippage + costs); no trade = 0")
    # bar helpers
    C = np.array([[np.nan, 101.0, np.nan, 103.0] + [np.nan] * (NB - 4)])
    pcs = B2.prev_closes(C, np.array([99.0]))
    check(same(pcs[0, :5], [99.0, 99.0, 101.0, 101.0, 103.0]),
          "the close before a bar: the previous session's close until a bar closes, then the last close (missing bars carried)")
    H, L, C2 = np.array([[3.0, 6, np.nan, 9] + [9.0] * (NB - 4)]), np.array([[1.0, 2, np.nan, 3] + [3.0] * (NB - 4)]), np.array([[2.0, 4, np.nan, 6] + [6.0] * (NB - 4)])
    av = B2.running_tp_mean(H, L, C2)
    check(same(av[0, :4], [2.0, 3.0, 3.0, 4.0]), "index session average: the running mean of typical prices (2, 4, -, 6 -> 2, 3, 3, 4)")
    rng = np.random.default_rng(3)
    Cr = 100 * np.exp(np.cumsum(rng.normal(0, 0.002, (4, NB)), 1))
    Cr[1, 10:13] = np.nan
    Hr, Lr = Cr * (1 + rng.uniform(0, 0.002, Cr.shape)), Cr * (1 - rng.uniform(0, 0.002, Cr.shape))
    e9 = B2.ema_rows(Cr, 9)
    ok = all(same(e9[i], WW.l_ema(list(Cr[i]), 9)) for i in range(4))
    lb, ub = B2.supertrend_bands(Hr, Lr, Cr, 17, 2.0)
    ok2 = all(same(lb[i], st_loop(Hr[i], Lr[i], Cr[i])[0]) and same(ub[i], st_loop(Hr[i], Lr[i], Cr[i])[1]) for i in range(4))
    check(ok and ok2, "EMA(9) and SuperTrend(17, 2) bands equal plain loops (Wilder ATR from bar 16; the lower band only rises unless "
                      "the previous close broke it), missing bars included")
    # participation
    TV = np.ones((13, NB)) * 10.0
    TV[:12, 5] = 20.0
    TV[12, 5] = 80.0
    use = np.ones(13, bool)
    use[3] = False
    r3 = B2.rvol(TV, use, 3)
    check(np.isnan(r3[10]).all() and abs(r3[12, 5] - (10 + 10 + 80) / 40.0) < 1e-12 and abs(r3[12, 2] - 1.0) < 1e-12 and abs(r3[11, 0] - 1.0) < 1e-12,
          "participation RVOL: bars k-2..k over the same bars of the previous 14 sessions (an unusable one skipped, at least 10): "
          "2.5x at bar 5 of the 13th session; NaN until 10 usable sessions exist")
    hok = B2.history_ok(use)
    check(not hok[10] and hok[11] and hok[12], "a stock-day needs 10 usable sessions among the previous 14 (the 11th usable session is the first)")
    x = np.arange(50, dtype=float)
    sh = B2.hist_share_below(x[::-1].copy(), np.ones(50, bool), 60, 40)
    md = B2.hist_median(x, np.ones(50, bool), 60, 40)
    check(np.isnan(sh[39]) and sh[40] == 0.0 and sh[49] == 0.0 and abs(md[40] - 19.5) < 1e-12 and abs(md[49] - 24.0) < 1e-12,
          "coil history: share of the previous sessions below today's (falling widths -> 0) and their median, from 40 sessions on")
    # market state
    O0 = np.array([100.0] * 5)
    Hs = np.full((5, NB), 100.5)
    Ls = np.full((5, NB), 99.5)
    Cf = np.full((5, NB), 100.0)
    Hs[0, 3] = 102.0                     # traded above PDH 101, closes back inside -> TRAP
    Cf[1, 14] = 101.5                    # bar 14 closes above PDH -> KINETIC
    Cf[2, 14] = 100.6                    # inside, but 0.6% from the open >= sigma 0.5% -> KINETIC
    sig = np.array([0.005, 0.005, 0.005, 0.005, np.nan])
    st = B2.market_state(Hs, Ls, Cf, O0, np.full(5, 101.0), np.full(5, 99.0), sig, np.ones(5, bool))
    check(list(st) == ["TRAP", "KINETIC", "KINETIC", "RANGE", "NA"],
          f"10:00 state: swept and back inside = TRAP; outside = KINETIC; |move| >= sigma = KINETIC; else RANGE; no sigma = NA ({list(st)})")
    # the trap rule
    o, h, l, c = flat(100.0)
    h[20], l[20], c[20] = 101.2, 100.9, 101.1     # bar 20 breaks above 101 (the close before it, 100, is <= 101), closes above
    h[21], l[21], c[21] = 101.5, 101.0, 101.05    # bar 21 stays above (its close-before is above the level: no new break)
    h[22], l[22], c[22] = 101.06, 100.3, 100.4    # bar 22 closes back below 101 and below the average -> snap (within m = 3)
    avg = np.full((1, NB), 100.5)
    up, dn = np.array([101.0]), np.array([99.0])
    t3 = B2.trap(h[None], l[None], c[None], avg, up, dn, np.array([100.0]), 15, 3)
    t2 = B2.trap(h[None], l[None], c[None], avg, up, dn, np.array([100.0]), 15, 2)
    check(t3[-1][0][0] == 22 and t3[-1][1][0] == 20 and abs(t3[-1][2][0] - 101.5) < 1e-12 and t2[-1][0][0] == -1 and t3[1][0][0] == -1,
          "trap: break at bar 20, snap at bar 22 -> short at bar 23, stop extreme = the highest high from 20 to 22 (101.5); "
          "with m = 2 the snap comes too late; nothing on the long side")
    o, h, l, c = flat(100.0)
    h[30], c[30] = 101.3, 100.3            # a wick: breaks and closes back below the level and the average in the same bar
    tw = B2.trap(h[None], l[None], c[None], avg, up, dn, np.array([100.0]), 15, 3)
    o, h, l, c = flat(101.5)               # already above the level all day: no fresh break until it dips and re-crosses
    c[40], l[40] = 100.8, 100.7
    h[41], c[41] = 101.6, 100.4
    ts = B2.trap(h[None], l[None], c[None], np.full((1, NB), 101.4), up, dn, np.array([101.5]), 15, 3)
    check(tw[-1][0][0] == 30 and tw[-1][1][0] == 30 and ts[-1][1][0] == 41 and ts[-1][0][0] == 41,
          "a wick snap is the break bar itself; a level the price already holds is only 'broken' after a close below it (bar 41)")
    trade_engine_by_hand()
    books_by_hand()
    gates_verdicts_by_hand()
    h6_by_hand()
    r1 = B2.rnd(pd.to_datetime(["2024-01-02"] * 3 + ["2024-01-03"]), ["AAA", "BBB", "AAA", "AAA"])
    r2 = B2.rnd(pd.to_datetime(["2024-01-02"] * 3 + ["2024-01-03"]), ["AAA", "BBB", "AAA", "AAA"])
    many_d = pd.to_datetime("2024-01-01") + pd.to_timedelta(np.arange(40000) % 200, unit="D")
    many_s = [f"S{i // 200}" for i in range(40000)]                   # 200 stocks x 200 days, all distinct
    a_, b_ = B2.rnd(many_d, many_s), B2.rnd(many_d, many_s, salt="side")
    A_ = a_.reshape(200, 200)
    lag = np.corrcoef(A_[:, :-1].ravel(), A_[:, 1:].ravel())[0, 1]
    dec = np.histogram(a_, bins=10, range=(0, 1))[0]
    u_ns = B2.rnd(pd.DatetimeIndex(np.array(["2024-01-01", "2024-01-02"], dtype="datetime64[ns]")), ["A", "A"])
    u_s = B2.rnd(pd.DatetimeIndex(np.array(["2024-01-01", "2024-01-02"], dtype="datetime64[s]")), ["A", "A"])
    check(same(r1, r2) and r1[0] == r1[2] and r1[0] != r1[1] and r1[0] != r1[3] and abs(a_.mean() - 0.5) < 0.015
          and abs(np.corrcoef(a_, b_)[0, 1]) < 0.02 and abs(lag) < 0.02 and dec.min() > 3600 and same(u_ns, u_s) and u_ns[0] != u_ns[1],
          f"fixed random numbers: the same stock-day gives the same number on every call; 40,000 stock-days: mean {a_.mean():.3f}, "
          f"deciles {dec.min()}-{dec.max()}, day-to-day correlation {lag:+.3f}, tie-break vs coin {np.corrcoef(a_, b_)[0, 1]:+.3f}; the "
          f"same in seconds or nanoseconds (an earlier draft gave every day of a stock the same number under pandas 3)")


def st_loop(H, L, C, n=17, mult=2.0):
    """SuperTrend final bands, plain loop (TradingView's recursion, within the day, Wilder ATR seeded at bar n-1)."""
    Hf, Lf, Cf = (pd.Series(x).ffill().to_numpy() for x in (H, L, C))
    lbs, ubs = [np.nan] * NB, [np.nan] * NB
    atr = np.nan
    trs = []
    for k in range(NB):
        tr = Hf[k] - Lf[k] if k == 0 else max(Hf[k] - Lf[k], abs(Hf[k] - Cf[k - 1]), abs(Lf[k] - Cf[k - 1]))
        trs.append(tr)
        if k == n - 1:
            atr = float(np.mean(trs))
        elif k >= n:
            atr = (atr * (n - 1) + tr) / n
        if k < n - 1:
            continue
        hl2 = (Hf[k] + Lf[k]) / 2
        lb, ub = hl2 - mult * atr, hl2 + mult * atr
        if k == n - 1:
            lbs[k], ubs[k] = lb, ub
            continue
        pl, pu = lbs[k - 1], ubs[k - 1]
        lbs[k] = lb if (lb > pl or Cf[k - 1] < pl) else pl
        ubs[k] = ub if (ub < pu or Cf[k - 1] > pu) else pu
    return np.array(lbs), np.array(ubs)


def trade_engine_by_hand():
    o, h, l, c = flat(100.0)
    o[11], h[11], l[11], c[11] = 100.0, 100.2, 99.4, 99.6         # entry at the open of bar 11; its low touches the stop 99.5
    r = B2.trade_outcomes(sess(o, h, l, c), 1, 11, 99.5, 116)
    check(r["kind"][0] == B2.KIND_STOP and r["exit_bar"][0] == 11 and abs(r["gross"][0] - (99.5 / 100 - 1)) < 1e-12 and r["stop_in_entry_bar"][0],
          "entry at the open; a stop touched in the entry bar fills at the stop (the open was the entry, so no gap)")
    o, h, l, c = flat(100.0)
    o[30], h[30], l[30], c[30] = 98.0, 98.2, 97.9, 98.1             # bar 30 opens through the stop 99.5 -> filled at the open
    r = B2.trade_outcomes(sess(o, h, l, c), 1, 11, 99.5, 116)
    check(r["kind"][0] == B2.KIND_STOP and r["exit_bar"][0] == 30 and abs(r["gross"][0] - (98.0 / 100 - 1)) < 1e-12,
          "a later bar that opens through the stop fills at its open (gap)")
    o, h, l, c = flat(100.0)
    o[116:118] = np.nan
    h[116:118] = l[116:118] = c[116:118] = np.nan
    o[118] = 100.7
    r = B2.trade_outcomes(sess(o, h, l, c), -1, 11, 101.0, 116)
    check(r["kind"][0] == B2.KIND_TIME and r["exit_bar"][0] == 118 and abs(r["gross"][0] - (1 - 100.7 / 100)) < 1e-12,
          "time exit at the 15:03 open; when that bar is missing, the next open that exists (short)")
    r = B2.trade_outcomes(sess(*flat(100.0)), 1, 11, 100.5, 116)
    check(r["kind"][0] == B2.KIND_NONE and r["beyond_stop"][0] and np.isnan(r["gross"][0]),
          "an entry bar that opens at or beyond the stop is no trade (counted)")
    o, h, l, c = flat(100.0)
    c[40] = 99.0
    W = np.zeros((1, NB), bool)
    W[0, 40] = True
    o[41] = 99.2
    r = B2.trade_outcomes(sess(o, h, l, c), 1, 11, 98.0, 116, trail=W)
    check(r["kind"][0] == B2.KIND_TRAIL and r["exit_bar"][0] == 41 and abs(r["gross"][0] - (99.2 / 100 - 1)) < 1e-12,
          "trail: a close on the wrong side at bar 40 exits at the open of bar 41")
    # P1: entry 100, stop 99 (R = 1); add 0.5 at 101 from bar 12; then the stop moves to 100 from the next bar
    o, h, l, c = flat(100.0)
    o[20], h[20], l[20], c[20] = 100.6, 101.3, 100.5, 101.2           # add fills at 101 (bar 20)
    for k in range(21, 30):
        o[k], h[k], l[k], c[k] = 101.2, 101.25, 101.15, 101.2         # holds above the new stop
    o[30], h[30], l[30], c[30] = 100.4, 100.5, 99.9, 100.1            # the new stop 100 is hit at bar 30 -> exit at 100
    for k in range(31, NB):
        o[k], h[k], l[k], c[k] = 100.1, 100.15, 100.05, 100.1
    P1 = [(1.0, 0.5, 0.0)]
    r = B2.trade_outcomes(sess(o, h, l, c), 1, 11, 99.0, 116, adds=P1)
    check(r["Z"][0] == 1.5 and r["kind"][0] == B2.KIND_STOP and r["exit_bar"][0] == 30 and abs(r["gross"][0] - (0.0 + 0.5 * (100 / 101 - 1))) < 1e-12,
          "P1: +0.5 at +1R (101), the stop moves to the entry from the next bar; stopped at 100: the base unit flat, the add "
          f"loses ({r['gross'][0] * 1e4:+.1f} bp) - '+1R = zero risk' is false")
    o, h, l, c = flat(100.0)
    o[20], h[20], l[20], c[20] = 100.6, 101.3, 98.8, 99.0             # add level 101 and old stop 99 in the same bar, open between
    r = B2.trade_outcomes(sess(o, h, l, c), 1, 11, 99.0, 116, adds=P1)
    check(r["Z"][0] == 1.5 and r["exit_bar"][0] == 20 and r["worst_order"][0] and abs(r["gross"][0] - (-0.01 + 0.5 * (99 / 101 - 1))) < 1e-12,
          "add and stop in one bar, open between them: worst order (add at 101, then the old stop 99 on 1.5 units), flagged")
    o[20] = 98.5
    r = B2.trade_outcomes(sess(o, h, l, c), 1, 11, 99.0, 116, adds=P1)
    check(r["Z"][0] == 1.0 and abs(r["gross"][0] - (98.5 / 100 - 1)) < 1e-12 and not r["worst_order"][0],
          "the same bar opening through the stop: stopped at the open, no add (the open settles the order)")
    o[20], l[20] = 101.5, 98.8
    r = B2.trade_outcomes(sess(o, h, l, c), 1, 11, 99.0, 116, adds=P1)
    check(r["Z"][0] == 1.5 and abs(r["gross"][0] - (-0.01 + 0.5 * (99 / 101.5 - 1))) < 1e-12 and not r["worst_order"][0],
          "the same bar opening beyond the add level: add at the open (101.5), then the stop (known order, not flagged)")
    o, h, l, c = flat(100.0)
    o[20], h[20], l[20], c[20] = 100.6, 101.3, 100.5, 101.2           # add 1 at 101
    for k in range(21, 25):
        o[k], h[k], l[k], c[k] = 101.2, 101.25, 101.15, 101.2
    o[25], h[25], l[25], c[25] = 101.5, 102.4, 101.4, 102.3           # add 2 (0.25) at 102; stop -> 101 from bar 26
    for k in range(26, 50):
        o[k], h[k], l[k], c[k] = 102.3, 102.35, 102.25, 102.3
    o[50], h[50], l[50], c[50] = 101.2, 101.3, 100.8, 100.9           # opens at 101.2, falls through the stop 101
    P2 = [(1.0, 0.5, 0.0), (2.0, 0.25, 1.0)]
    r = B2.trade_outcomes(sess(o, h, l, c), 1, 11, 99.0, 116, adds=P2)
    exp_g = (101 / 100 - 1) + 0.5 * (101 / 101 - 1) + 0.25 * (101 / 102 - 1)
    check(r["Z"][0] == 1.75 and r["exit_bar"][0] == 50 and abs(r["gross"][0] - exp_g) < 1e-12,
          f"P2: adds at 101 and 102, the stop moves to +1R (101) after the second; stopped there: {exp_g * 1e4:+.1f} bp of a base position")
    o, h, l, c = flat(100.0)
    o[20], h[20], l[20], c[20] = 99.4, 99.5, 98.7, 98.9               # short: add at 99 (entry 100, stop 101)
    for k in range(21, 116):
        o[k], h[k], l[k], c[k] = 98.9, 98.95, 98.85, 98.9             # stays below the new stop 100
    o[116] = 100.0                                                    # the time exit opens at 100
    r = B2.trade_outcomes(sess(o, h, l, c), -1, 11, 101.0, 116, adds=P1)
    check(r["Z"][0] == 1.5 and r["kind"][0] == B2.KIND_TIME and abs(r["gross"][0] - ((1 - 100 / 100) + 0.5 * (1 - 100 / 99))) < 1e-12,
          "short mirror: the add sells at 99 (+1R), the stop moves to 100; the time exit at 100: the add loses")


def books_by_hand():
    d1, d2 = pd.Timestamp("2024-03-01"), pd.Timestamp("2024-03-04")
    T = pd.DataFrame({"day": [d1] * 5 + [d2] * 2, "symbol": ["A", "B", "C", "D", "E", "A", "B"], "side": 1,
                      "eb": [10, 3, 3, 3, 50, 7, 8], "score": [9.0, 1.0, 5.0, 2.0, 0.0, 1.0, 1.0],
                      "gross": [0.01, 0.02, -0.01, 0.03, 0.05, 0.004, -0.002], "kind": B2.KIND_TIME, "slip_bp": 8.0, "cost_bp": 4.5})
    P = B2.fcfs(T, 3)
    check(list(P.loc[P["day"] == d1, "symbol"]) == ["C", "D", "B"] and list(P.loc[P["day"] == d2, "symbol"]) == ["A", "B"]
          and (P["w"] == 1 / 3).all(),
          "N-slot book: bar 3's three triggers fill the 3 slots by score (C 5, D 2, B 1); A at bar 10 and E at bar 50 find none; "
          "a day with 2 triggers fills 2 slots")
    cal = np.array([d1, d2], dtype="datetime64[ns]")
    dl = B2.daily_of(P, cal)
    net = lambda g: g - (8 + 4.5) / 1e4
    check(abs(dl[1.0][0] - (net(-0.01) + net(0.03) + net(0.02)) / 3) < 1e-12 and abs(dl[1.0][1] - (net(0.004) + net(-0.002)) / 3) < 1e-12
          and abs(dl[1.5][0] - (net(-0.01) + net(0.03) + net(0.02) - 3 * 4 / 1e4) / 3) < 1e-12,
          "daily return = each slot's net / N (cash in unused slots); x1.5 slippage adds half the slippage again")
    md = B2.matched_daily(T, cal, 3)
    check(abs(md[0] - 3 / 3 * np.mean([net(g) for g in (0.01, 0.02, -0.01, 0.03, 0.05)])) < 1e-12
          and abs(md[1] - 2 / 3 * np.mean([net(0.004), net(-0.002)])) < 1e-12 and abs(md[1] - dl[1.0][1]) < 1e-12,
          "exposure-matched average trigger: min(count, N)/N x the mean of ALL the day's triggers (identical to the book on a "
          "day with N or fewer)")


def gates_verdicts_by_hand():
    T = pd.DataFrame({"day": pd.to_datetime(["2024-03-01", "2024-03-01", "2024-03-04", "2024-03-05"]), "side": [1, -1, 1, 1],
                      "tb": [20, 8, 30, 30], "isync": [2.0, 1.0, np.nan, 0.0], "sync": [0.7, 0.5, np.nan, 2 / 3],
                      "breadth": [0.6, 0.6, np.nan, 0.4], "rvol": [2.5, 1.0, np.nan, 2.0]})
    states = pd.Series(["TRAP", "KINETIC"], index=pd.to_datetime(["2024-03-01", "2024-03-04"]))
    ok, j = B2.gate_pass(T, "state", "X1", states)
    check(list(ok) == [True, True, False, True] and list(j) == [True, False, True, False],
          "state gate (X1: TRAP or RANGE): a TRAP day passes, a KINETIC day fails; judged only at or after the close of bar 14 "
          "with a known state - the 09:39 trigger and a day without a state pass unjudged")
    ok2, _ = B2.gate_pass(T, "isync2", "X1", states)
    ok1, _ = B2.gate_pass(T, "isync1", "X1", states)
    oks, js = B2.gate_pass(T, "sector", "S1", states)
    okb, _ = B2.gate_pass(T, "breadth", "S1", states)
    okp, _ = B2.gate_pass(T, "participation", "S1", states)
    check(list(ok2) == [True, False, True, False] and list(ok1) == [True, True, True, False] and list(oks) == [True, False, True, True]
          and list(js) == [True, True, False, True] and list(okb) == [True, False, True, False] and list(okp) == [True, False, True, True],
          "BANK/IT = 2 and >= 1; sector sync >= 2/3 (exactly 2/3 passes); breadth on the trade's side (0.6 long yes, short no); "
          "participation >= 2; NaN = cannot judge = passes")
    check(B2.gates_for("X1") == ["state", "isync2", "isync1", "breadth", "participation"] and B2.gates_for("S3") == ["sector", "breadth", "participation"]
          and B2.gates_for("X3") == ["isync2", "isync1", "breadth", "participation"],
          "gates per family: X3 and S3 have no state gate (LSAP names none)")
    good = {"lo_bp": 1.0, "mean_bp": 3.0, "sharpe": 2.0, "mean_bp_x1.5": 2.0, "trades": 40}
    conf = {"mean_bp": 2.0, "sharpe": 1.2, "mean_bp_x1.5": 1.0}
    check(not B2._pos(4.06e-18) and not B2._pos(0.0) and B2._pos(1e-6) and not B2._pos(np.nan),
          "strictly above zero: a lower bound of 4e-18 bp (exactly zero plus float noise) is not a pass")
    check(B2.verdict(good, conf, 0.97, 0.01) == "CHAMPION" and B2.verdict(good, conf, 0.90, 0.01) == "PROMISING"
          and B2.verdict(good, conf, 0.97, 0.08) == "WATCH" and B2.verdict({**good, "trades": 29}, conf, 0.97, 0.01) == "WATCH"
          and B2.verdict(good, {**conf, "sharpe": 0.9}, 0.97, 0.01) == "PROMISING"
          and B2.verdict({**good, "lo_bp": -1.0, "mean_bp": -1.0}, {**conf, "mean_bp": -0.5}, 0.97, 0.01) == "DEAD"
          and B2.verdict(good, conf, 0.97, np.nan) == "WATCH",
          "verdicts: CHAMPION needs DSR, half the Sharpe kept and stress; PROMISING needs p (search) < 0.05 and 30 trades; a missing "
          "p (search) is not a pass")


def h6_by_hand():
    cal = pd.bdate_range("2024-01-01", periods=30).values
    A = pd.DataFrame({"coil": 2, "coil_exp": 1, "nocoil": 10, "nocoil_exp": 2}, index=pd.DatetimeIndex(cal))
    T = B2.h6_stats(None, None, A, cal, {})
    r = T[T["window"] == "disc"].iloc[0]
    check(abs(r["p_exp_given_coil"] - 0.5) < 1e-12 and abs(r["p_exp_given_no_coil"] - 0.2) < 1e-12 and abs(r["diff_pp"] - 30.0) < 1e-9,
          "H6 (stocks): P(exp | coil) 1/2, P(exp | no coil) 2/10, daily difference +30 pp")
    nd = pd.bdate_range("2024-01-01", periods=40)
    h = {"defined": np.ones(40, bool), "coil": np.r_[np.ones(10, bool), np.zeros(30, bool)], "exp": np.r_[np.ones(5, bool), np.zeros(5, bool), np.ones(3, bool), np.zeros(27, bool)]}
    T2 = B2.h6_stats(h, nd.values, None, nd.values, {})
    r2 = T2[T2["window"] == "disc"].iloc[0]
    check(abs(r2["p_exp_given_coil"] - 0.5) < 1e-12 and abs(r2["p_exp_given_no_coil"] - 0.1) < 1e-12 and abs(r2["diff_pp"] - 40.0) < 1e-9
          and r2["diff_lo_pp"] < 40 < r2["diff_hi_pp"],
          f"H6 (NIFTY): 5 of 10 coil days expand vs 3 of 30 -> +40 pp, interval [{r2['diff_lo_pp']:.1f}, {r2['diff_hi_pp']:.1f}] from day blocks")


# ----------------------------------------------------------------------
# 2. the trade engine against an independent loop
# ----------------------------------------------------------------------
def ref_trade(O, H, L, C, side, e, S0, xbar, adds=(), wrong=None):
    """One trade, bar by bar (independent of the vectorised engine)."""
    fin = WW.fin
    ee = next((k for k in range(e, 106) if fin(O[k])), -1) if e >= 0 else -1
    if ee < 0 or not fin(S0):
        return None
    E = O[ee]
    if (side > 0 and E <= S0) or (side < 0 and E >= S0):
        return "beyond"
    R = abs(E - S0)
    stop, units, ia, live = S0, [(E, 1.0)], 0, ee + 1
    exit_px = exit_bar = kind = None

    def time_px():
        j = next((k for k in range(xbar, NB) if fin(O[k])), -1)
        if j >= 0:
            return O[j], j
        lc = next((C[k] for k in range(xbar - 1, -1, -1) if fin(C[k])), np.nan)
        return lc, xbar

    for k in range(ee, NB):
        if k >= xbar:
            break
        hit = fin(H[k]) and fin(L[k]) and ((L[k] <= stop) if side > 0 else (H[k] >= stop))
        A = E + side * adds[ia][0] * R if ia < len(adds) else None
        add = A is not None and k >= live and fin(H[k]) and ((H[k] >= A) if side > 0 else (L[k] <= A))
        if hit and add:
            if (side > 0 and O[k] <= stop) or (side < 0 and O[k] >= stop):
                exit_px, exit_bar, kind = O[k], k, 1
                break
            units.append((max(A, O[k]) if side > 0 else min(A, O[k]), adds[ia][1]))
            exit_px, exit_bar, kind = stop, k, 1
            break
        if hit:
            exit_px = stop if k == ee else (min(stop, O[k]) if side > 0 else max(stop, O[k]))
            exit_bar, kind = k, 1
            break
        if add:
            units.append((max(A, O[k]) if side > 0 else min(A, O[k]), adds[ia][1]))
            stop = E + side * adds[ia][2] * R
            ia += 1
            live = k + 1
        if wrong is not None and k <= xbar - 2 and wrong[k]:
            j = next((q for q in range(k + 1, xbar + 1) if fin(O[q])), -1)
            if j >= 0:
                exit_px, exit_bar = O[j], j
            else:
                exit_px, exit_bar = time_px()
            kind = 3
            break
    if kind is None:
        exit_px, exit_bar = time_px()
        kind = 2
    g = sum(z * side * (exit_px / p - 1) for p, z in units)
    return {"entry": E, "exit_bar": exit_bar, "kind": kind, "Z": sum(z for _, z in units), "gross": g}


def engine_vs_loop():
    print("2. the trade engine against an independent bar-by-bar loop")
    rng = np.random.default_rng(21)
    n = 3000
    rets = rng.normal(0, 0.0025, (n, NB))
    O = 100 * np.exp(np.concatenate([np.zeros((n, 1)), np.cumsum(rets, 1)[:, :-1]], 1))
    C = 100 * np.exp(np.cumsum(rets, 1))
    u1, u2 = 1 - rng.random((n, NB)), 1 - rng.random((n, NB))
    lo_, lc = np.log(O), np.log(C)
    s2 = 0.0025 ** 2
    H = np.exp((lo_ + lc + np.sqrt((lc - lo_) ** 2 - 2 * s2 * np.log(u1))) / 2)
    L = np.exp((lo_ + lc - np.sqrt((lc - lo_) ** 2 - 2 * s2 * np.log(u2))) / 2)
    gapbar = rng.random((n, NB)) < 0.03                  # occasional gaps: the bar opens away from the last close
    O = np.where(gapbar, O * np.exp(rng.normal(0, 0.004, (n, NB))), O)
    H, L = np.maximum(H, O), np.minimum(L, O)
    miss = rng.random((n, NB)) < 0.02
    miss[:, 0] = False
    for A in (O, H, L, C):
        A[miss] = np.nan
    side = rng.choice([-1, 1], n)
    e = rng.integers(1, 106, n)
    dist = rng.uniform(0.001, 0.012, n)
    E0 = np.array([O[i, e[i]] if np.isfinite(O[i, e[i]]) else 100.0 for i in range(n)])
    S0 = E0 * (1 - side * dist)
    S0[:30] = E0[:30] * (1 + side[:30] * 0.001)          # some entries open beyond their stop
    B = {"open": O, "high": H, "low": L, "close": C}
    V = B2.variants(B, side, e, S0, 116)
    ema = B2.ema_rows(C, 22)
    lb, ub = B2.supertrend_bands(H, L, C, 17, 2.0)
    wr = {"base": None, "P1": None, "P2": None, "T1": B2.wrong_side(C, ema, ema, side), "T2": B2.wrong_side(C, lb, ub, side)}
    wr["P1T1"] = wr["T1"]
    adds = {"P1": [(1.0, 0.5, 0.0)], "P2": [(1.0, 0.5, 0.0), (2.0, 0.25, 1.0)], "P1T1": [(1.0, 0.5, 0.0)]}
    bad = {}
    for name in ("base", "P1", "P2", "T1", "T2", "P1T1", "mirror"):
        r = V[name]
        nb_ = 0
        for i in range(n):
            if name == "mirror":
                if not np.isfinite(V["base"]["entry"][i]):
                    continue
                ref = ref_trade(O[i], H[i], L[i], C[i], -side[i], e[i], 2 * V["base"]["entry"][i] - S0[i], 116)
            else:
                ref = ref_trade(O[i], H[i], L[i], C[i], side[i], e[i], S0[i], 116, adds.get(name, ()),
                                None if wr[name] is None else wr[name][i])
            if ref is None or ref == "beyond":
                nb_ += int(r["kind"][i] != B2.KIND_NONE)
                continue
            ok = (r["kind"][i] == ref["kind"] and r["exit_bar"][i] == ref["exit_bar"] and abs(r["Z"][i] - ref["Z"]) < 1e-12
                  and abs(r["gross"][i] - ref["gross"]) < 1e-12 and abs(r["entry"][i] - ref["entry"]) < 1e-12)
            nb_ += int(not ok)
        bad[name] = nb_
    n_add = int((V["P2"]["Z"] > 1.5).sum())
    n_worst = int(V["P1"]["worst_order"].sum())
    check(all(v == 0 for v in bad.values()) and n_add > 100 and int((V["T2"]["kind"] == B2.KIND_TRAIL).sum()) > 500,
          f"{n} random sessions (3% gap opens, 2% missing bars): the vectorised engine equals the loop in every variant "
          f"(mismatches {bad}); {n_add} second adds, {n_worst} worst-order bookings, "
          f"{int((V['T2']['kind'] == B2.KIND_TRAIL).sum())} SuperTrend exits exercised")


# ----------------------------------------------------------------------
# 3. two implementations of every trigger rule
# ----------------------------------------------------------------------
def build_ctx(w, sectors=True):
    """The study's per-instrument contexts and market paths for a world (passes 0 and the index pass)."""
    feats = {s: BM.daily_features(D) for s, D in w["daily"].items()}
    bars = {s: BM.bar_matrix(w["intra"][s]) for s in feats}
    t0 = pd.Timestamp(w["intra"]["S000"]["timestamp"].min()).normalize()
    cal = np.array(sorted(set(pd.DatetimeIndex(w["days"][w["days"] >= t0]))), dtype="datetime64[ns]")
    sec = w.get("sector_of") or {} if sectors else {}
    top = B2.top_liquid(feats, cal, 50)
    mkt = B2.Market(cal, list(sec.values()))
    for s, F in feats.items():
        days, B = bars[s]
        _, _, ok = B2.agg_mask(F, days, B, BM.liquid_ok(F))
        if ok.any():
            tp = np.array([s in top.get(pd.Timestamp(d), ()) for d in days[ok]])
            mkt.add(sec.get(s), days[ok], BM.since_open(B["close"][ok], B["open"][ok, 0]), (B["volume"] * B["close"])[ok], tp)
    dd = {}
    for k in ("nifty_daily", "bank_daily", "it_daily"):
        X = w[k].copy()
        X["day"] = BM.SI._naive_days(X["timestamp"]).to_numpy()
        dd[k] = X
    ix = B2.index_ctx(w["nifty_bars"], dd["nifty_daily"], {"NIFTY BANK": (w.get("bank_bars"), dd["bank_daily"]),
                                                            "NIFTY IT": (w.get("it_bars"), dd["it_daily"])}, mkt, {})
    return {"feats": feats, "bars": bars, "t0": t0, "cal": cal, "sec": sec, "mkt": mkt, "ix": ix, "nd": dd["nifty_daily"]}


def cross_check():
    print("3. two implementations of every trigger rule (vectorised study code vs plain loops)")
    t_ = time.perf_counter()
    w = WW.make_world(n=14, seed=5, missing_bars=0.02, vol_spike=0.15, exhaust=0.08, mkt_spike=0.03)
    X = build_ctx(w)
    ix = X["ix"]
    mism, n_trig, n_cmp = {}, {}, {}
    # index families
    H, L, C, O = ix["high"], ix["low"], ix["close"], ix["open"]
    for fam in B2.INDEX_FAMS:
        for tv, prm in B2.CELLS[fam]:
            vt = B2.index_triggers(fam, prm, ix)
            for i in np.flatnonzero(ix["use"]):
                lp = loop_index(fam, prm, ix, i)
                for side in (1, -1):
                    a = (int(vt[side][0][i]), int(vt[side][1][i]), float(vt[side][2][i]) if vt[side][0][i] >= 0 else np.nan)
                    b = lp[side]
                    key = f"{fam} {tv}"
                    n_cmp[key] = n_cmp.get(key, 0) + 1
                    n_trig[key] = n_trig.get(key, 0) + int(a[0] >= 0)
                    if not (a[0] == b[0] and a[1] == b[1] and same([a[2]], [b[2]], 1e-12)):
                        mism[key] = mism.get(key, 0) + 1
    # stock families
    nifty_P = {pd.Timestamp(d): ix["P"][i] for i, d in enumerate(ix["days"]) if ix["use"][i]}
    for s in sorted(X["feats"]):
        F = X["feats"][s]
        days, B = X["bars"][s]
        cx = B2.stock_ctx(F, days, B, BM.liquid_ok(F), X["t0"])
        D = len(days)
        sync = dict(zip((1, -1), X["mkt"].sync(X["sec"].get(s), days, cx["P"], cx["agg_ok"])))
        NP = np.full((D, NB), np.nan)
        for k, d in enumerate(days):
            if pd.Timestamp(d) in nifty_P:
                NP[k] = nifty_P[pd.Timestamp(d)]
        beta = BM.beta_series(F, X["nd"])
        bet = np.where(cx["trow"] >= 1, beta[np.maximum(cx["trow"] - 1, 0)], np.nan)
        for fam in B2.STOCK_FAMS:
            for tv, prm in B2.CELLS[fam]:
                vt = B2.stock_triggers(fam, prm, cx, NP, bet, sync)
                for i in np.flatnonzero(cx["cand"]):
                    lp = loop_stock(fam, prm, cx, i, NP[i], bet[i], {sd: sync[sd][i] for sd in (1, -1)})
                    for side in (1, -1):
                        a = (int(vt[side][0][i]), int(vt[side][1][i]), float(vt[side][2][i]) if vt[side][0][i] >= 0 else np.nan)
                        b = lp[side][:3]
                        key = f"{fam} {tv}"
                        n_cmp[key] = n_cmp.get(key, 0) + 1
                        n_trig[key] = n_trig.get(key, 0) + int(a[0] >= 0)
                        ok = a[0] == b[0] and a[1] == b[1] and same([a[2]], [b[2]], 1e-12)
                        if ok and a[0] >= 0 and len(lp[side]) > 3:
                            ok = same([vt[side][3][i]], [lp[side][3]], 1e-9)
                        if not ok:
                            mism[key] = mism.get(key, 0) + 1
    vw_ok = True
    for s in list(X["feats"])[:4]:
        days, B = X["bars"][s]
        vw = BM.session_vwap(B["high"], B["low"], B["close"], B["volume"])
        vw_ok &= all(same(vw[i], WW.l_vwap(B["high"][i], B["low"][i], B["close"][i], B["volume"][i])) for i in range(0, len(days), 7))
    trig_ok = all(n_trig.get(k, 0) > 0 for k in n_cmp if not k.startswith(("X1 m3|PD|div1", "X1 m5|PD|div1")))
    check(not mism and trig_ok and vw_ok,
          f"{sum(n_cmp.values()):,} session-sides compared over {len(n_cmp)} trigger variants (2% missing bars): mismatches "
          f"{mism or 0}; every variant triggered ({min(n_trig.values())} to {max(n_trig.values())} times); VWAP equals a plain loop "
          f"({time.perf_counter() - t_:.0f}s)")
    return w, X


def loop_index(fam, prm, ix, i):
    """The plain-loop version of an index cell on NIFTY's session i (context from the study: levels, participation)."""
    O, H, L, C = (list(ix[k][i]) for k in ("open", "high", "low", "close"))
    avg = WW.l_tp_mean(H, L, C)
    buf = 0.0002
    out = {1: (-1, -1, np.nan), -1: (-1, -1, np.nan)}
    ibh = max(x for x in H[:15] if WW.fin(x)) if any(WW.fin(x) for x in H[:15]) else np.nan
    ibl = min(x for x in L[:15] if WW.fin(x)) if any(WW.fin(x) for x in L[:15]) else np.nan
    if fam == "X1":
        up, dn = (ibh, ibl) if prm["level"] == "IB" else (ix["pdh"][i], ix["pdl"][i])
        eu = ed = None
        if prm["div"]:
            eu, ed = [False] * NB, [False] * NB
            for nm in ("NIFTY BANK", "NIFTY IT"):
                A = ix["others"][nm]
                if A is None:
                    continue
                HB, LB_, CB = (list(A[k][i]) for k in ("high", "low", "close"))
                avB = WW.l_tp_mean(HB, LB_, CB)
                if prm["level"] == "IB":
                    u = max([x for x in HB[:15] if WW.fin(x)], default=np.nan)
                    d_ = min([x for x in LB_[:15] if WW.fin(x)], default=np.nan)
                else:
                    u, d_ = A["pdh"][i], A["pdl"][i]
                du, dd = WW.l_divergence(HB, LB_, CB, avB, u, d_)
                eu = [a or b for a, b in zip(eu, du)]
                ed = [a or b for a, b in zip(ed, dd)]
        tr = WW.l_trap(H, L, C, avg, up, dn, ix["pdc"][i], 15, prm["m"], eu, ed)
        for side, (s, b, ext) in tr.items():
            if s >= 0:
                out[side] = (s, s + 1, ext * (1 + buf) if side < 0 else ext * (1 - buf))
    elif fam == "X2":
        P = avg if prm["pull"] == "avg" else WW.l_ema(C, 9)
        rv1 = list(ix["rv1"][i])
        for side in (1, -1):
            if side > 0:
                b = next((k for k in range(15, 105) if WW.fin(H[k]) and H[k] > ibh), -1)
                pull = [WW.fin(L[k]) and WW.fin(P[k]) and L[k] <= P[k] for k in range(NB)]
                rev = [k >= 1 and WW.fin(C[k]) and WW.fin(O[k]) and WW.fin(H[k - 1]) and C[k] > O[k] and C[k] > H[k - 1]
                       and WW.fin(rv1[k]) and rv1[k] >= prm["v"] for k in range(NB)]
            else:
                b = next((k for k in range(15, 105) if WW.fin(L[k]) and L[k] < ibl), -1)
                pull = [WW.fin(H[k]) and WW.fin(P[k]) and H[k] >= P[k] for k in range(NB)]
                rev = [k >= 1 and WW.fin(C[k]) and WW.fin(O[k]) and WW.fin(L[k - 1]) and C[k] < O[k] and C[k] < L[k - 1]
                       and WW.fin(rv1[k]) and rv1[k] >= prm["v"] for k in range(NB)]
            r, lo = WW.l_pullback(H, L, b, pull, rv1, rev, side)
            if r >= 0:
                seg = [(L if side > 0 else H)[k] for k in range(lo, r + 1) if WW.fin((L if side > 0 else H)[k])]
                ext = min(seg) if side > 0 else max(seg)
                stop = min(avg[r], ext) * (1 - buf) if side > 0 else max(avg[r], ext) * (1 + buf)
                out[side] = (r, r + 1, stop)
    else:
        bx = WW.l_box(H, L, C)
        cb = WW.l_coil(H, L, C, WW.fin(bx["width"]) and bx["width"] < prm["c"], bx, 2.0 if prm["exp"] else None)
        for side, (k, stop) in cb.items():
            if k >= 0:
                out[side] = (k, k + 1, stop)
    return out


def loop_stock(fam, prm, cx, i, nP, beta, sync):
    O, H, L, C, V = (list(cx[k][i]) for k in ("open", "high", "low", "close", "volume"))
    apx = cx["atrpx"][i]
    rv1, rv3 = list(cx["rv1"][i]), list(cx["rv3"][i])
    out = {1: (-1, -1, np.nan), -1: (-1, -1, np.nan)}
    if fam == "S1":
        vw = WW.l_vwap(H, L, C, V)
        if prm["level"] == "OR2":
            tr = WW.l_trap(H, L, C, vw, max(H[:2]), min(L[:2]), np.nan, 2, prm["m"])
        else:
            tr = WW.l_trap(H, L, C, vw, cx["pdh"][i], cx["pdl"][i], cx["pdc"][i], 0, prm["m"])
        for side, (s, b, ext) in tr.items():
            if s >= 0:
                out[side] = (s, s + 1, ext + 0.05 * apx if side < 0 else ext - 0.05 * apx, rv3[s])
    elif fam == "S2":
        vw = WW.l_vwap(H, L, C, V)
        orh, orl = max(H[:2]), min(L[:2])
        for side in (1, -1):
            if side > 0:
                b = next((k for k in range(2, 105) if WW.fin(H[k]) and H[k] > orh), -1)
                lvl = [orh] * NB if prm["level"] == "level" else vw
                pull = [WW.fin(L[k]) and WW.fin(lvl[k]) and L[k] <= lvl[k] + 0.25 * apx for k in range(NB)]
                rev = [k >= 1 and WW.fin(C[k]) and WW.fin(H[k - 1]) and C[k] > H[k - 1] for k in range(NB)]
            else:
                b = next((k for k in range(2, 105) if WW.fin(L[k]) and L[k] < orl), -1)
                lvl = [orl] * NB if prm["level"] == "level" else vw
                pull = [WW.fin(H[k]) and WW.fin(lvl[k]) and H[k] >= lvl[k] - 0.25 * apx for k in range(NB)]
                rev = [k >= 1 and WW.fin(C[k]) and WW.fin(L[k - 1]) and C[k] < L[k - 1] for k in range(NB)]
            r, lo = WW.l_pullback(H, L, b, pull, rv1, rev, side)
            if r >= 0:
                seg = [(L if side > 0 else H)[k] for k in range(lo, r + 1) if WW.fin((L if side > 0 else H)[k])]
                out[side] = (r, r + 1, (min(seg) - 0.10 * apx) if side > 0 else (max(seg) + 0.10 * apx), rv3[r])
    elif fam == "S3":
        bx = WW.l_box(H, L, C)
        sh = cx["box_share"][i]
        for side, (k, stop) in WW.l_coil(H, L, C, WW.fin(sh) and sh < prm["q"], bx, None).items():
            if k >= 0:
                out[side] = (k, k + 1, stop, rv3[k])
    elif fam == "S4":
        for side, (f, stop, sc) in WW.l_exhaustion(H, L, C, O[0], cx["atr"][i], cx["rv15"][i], prm["k"], apx).items():
            if f >= 0:
                out[side] = (f, f + 1, stop, sc)
    else:
        c = prm["check"]
        cc = WW.l_last_close(C, c)
        rs = (cc / O[0] - 1 - beta * nP[c]) / cx["atr"][i] if all(WW.fin(x) for x in (cc, beta, nP[c], cx["atr"][i])) else np.nan
        for side in (1, -1):
            sy = sync[side][c]
            if WW.fin(rs) and side * rs > 0 and (not WW.fin(sy) or sy >= 0.5):
                lo_ = min(x for x in L[: c + 1] if WW.fin(x))
                hi_ = max(x for x in H[: c + 1] if WW.fin(x))
                out[side] = (c, c + 1, (lo_ - 0.05 * apx) if side > 0 else (hi_ + 0.05 * apx), side * rs)
    return out


# ----------------------------------------------------------------------
# 4. fill fairness
# ----------------------------------------------------------------------
def driftless(n, rng, sd=0.0025):
    rets = rng.normal(0, sd, (n, NB))
    O = 100 * np.exp(np.concatenate([np.zeros((n, 1)), np.cumsum(rets, 1)[:, :-1]], 1))
    C = 100 * np.exp(np.cumsum(rets, 1))
    lo_, lc = np.log(O), np.log(C)
    u1, u2 = 1 - rng.random((n, NB)), 1 - rng.random((n, NB))
    H = np.exp((lo_ + lc + np.sqrt((lc - lo_) ** 2 - 2 * sd ** 2 * np.log(u1))) / 2)
    L = np.exp((lo_ + lc - np.sqrt((lc - lo_) ** 2 - 2 * sd ** 2 * np.log(u2))) / 2)
    return {"open": O, "high": H, "low": L, "close": C}


def fairness():
    print("4. fill fairness on continuous driftless paths")
    rng = np.random.default_rng(77)
    n = 120_000
    B = driftless(n, rng)
    side = rng.choice([-1, 1], n)
    e = rng.integers(1, 106, n)
    E0 = B["open"][np.arange(n), e]
    S0 = E0 * (1 - side * rng.uniform(0.0015, 0.012, n))
    V = B2.variants(B, side, e, S0, 116)
    rows, worst = [], True
    for name in ("base", "P1", "P2", "T1", "T2", "P1T1", "mirror"):
        g = V[name]["gross"]
        g = g[np.isfinite(g)]
        m, se = g.mean(), g.std(ddof=1) / np.sqrt(len(g))
        rows.append(f"{name} {m * 1e4:+.2f} bp (se {se * 1e4:.2f})")
        worst &= m < 3 * se
    check(worst, f"{n:,} sessions, every exit and add: no positive mean before costs (a fill that peeks inside a bar would show "
                 f"one): {'; '.join(rows)}")


# ----------------------------------------------------------------------
# the pipeline on a world (passes 0-3 in memory, as main() runs them)
# ----------------------------------------------------------------------
def pipeline(w, sectors=True, mgmt=True):
    X = build_ctx(w, sectors)
    ix = X["ix"]
    nifty_P = {pd.Timestamp(d): ix["P"][i] for i, d in enumerate(ix["days"]) if ix["use"][i]}
    states = pd.Series(ix["state"], index=pd.DatetimeIndex(ix["days"]))
    rows = B2.index_rows(ix)
    parts, h6p = {}, []
    for s, F in X["feats"].items():
        days, B = X["bars"][s]
        r_, h6 = B2.stock_rows(s, F, days, B, BM.liquid_ok(F), X["mkt"], nifty_P, BM.beta_series(F, X["nd"]), X["sec"].get(s), X["t0"])
        for k, v in r_.items():
            parts.setdefault(k, []).append(v)
        okh = h6["ok"] & h6.get("defined", np.zeros(len(days), bool))
        if okh.any():
            h6p.append(pd.DataFrame({"day": days[okh], "coil": h6["coil"][okh], "exp": h6["exp"][okh]}))
    for k, v in parts.items():
        T = pd.concat(v, ignore_index=True)
        T["symbol"] = T["symbol"].astype("category")
        rows[k] = T
    first_t = min(v["day"].min() for v in rows.values() if len(v))
    cal = X["cal"][X["cal"] >= np.datetime64(first_t)]
    res = B2.run_books(rows, cal, states)
    res["gates"] = B2.run_gates(res, states)
    if mgmt:
        mg = {}
        S = res["selected"]
        for _, b in S[S["pick"] == "selected"].iterrows():
            key = (b["side"], b["family"], b["cell"], int(b["top_n"]))
            P = res["store"][key]["picks"]
            if not len(P):
                continue
            if b["family"] in B2.INDEX_FAMS:
                mg[key] = B2.manage_index(ix, b["family"], b["cell"], P)
            else:
                lst = []
                for sym, Ps in P.groupby(P["symbol"].astype(str), observed=True):
                    days, B = X["bars"][sym]
                    cx = B2.stock_ctx(X["feats"][sym], days, B, BM.liquid_ok(X["feats"][sym]), X["t0"])
                    lst.append(B2.manage_stock(cx, b["family"], b["cell"], Ps))
                mg[key] = pd.concat(lst, ignore_index=True)
        res["mgmt_frames"] = mg
        res["management"], res["controls"] = B2.run_management(res, mg)
    res["h2"] = B2.h2_table(res)
    hs = None
    if h6p:
        Hh = pd.concat(h6p, ignore_index=True)
        g = Hh.groupby("day")
        hs = pd.DataFrame({"coil": g["coil"].sum(), "coil_exp": (Hh["coil"] & Hh["exp"]).groupby(Hh["day"]).sum(),
                           "nocoil": (~Hh["coil"]).groupby(Hh["day"]).sum(), "nocoil_exp": (~Hh["coil"] & Hh["exp"]).groupby(Hh["day"]).sum()})
    res["h6"] = B2.h6_stats(ix["h6"], ix["days"], hs, cal, res["idx_cache"])
    res["rows"], res["ix"], res["X"], res["states"] = rows, ix, X, states
    return res


def sel(res, side, fam):
    S = res["selected"]
    return S[(S["side"] == side) & (S["family"] == fam) & (S["pick"] == "selected")].iloc[0]


def gate(res, side, fam, g):
    G = res["gates"]
    return G[(G["side"] == side) & (G["family"] == fam) & (G["gate"] == g)].iloc[0]


def mgm(res, side, fam, v):
    M = res["management"]
    return M[(M["side"] == side) & (M["family"] == fam) & (M["variant"] == v)].iloc[0]


def wins(v):
    return v in ("PROMISING", "CHAMPION")


def vtab(res) -> str:
    S = res["selected"]
    S = S[S["pick"] == "selected"]
    return " ".join(f"{r['side']}{r['family']}:{r['verdict'][:4]}" for _, r in S.iterrows())


# ----------------------------------------------------------------------
# 5. look-ahead
# ----------------------------------------------------------------------
def perturb_world(w, t: pd.Timestamp, s_cut: int, seed: int):
    """A copy of the world in which every bar after bar s_cut of day t, and every later day, is changed (prices scaled by
    random factors, volumes redrawn); the daily bars from day t on are rebuilt from the changed bars."""
    rng = np.random.default_rng(seed)
    cut = t + pd.Timedelta(minutes=555 + 3 * s_cut)
    w2 = {k: v for k, v in w.items()}
    w2["intra"] = {}

    def pert(X):
        X = X.copy()
        m = (X["timestamp"] > cut).to_numpy()
        f = np.exp(np.cumsum(rng.normal(0, 0.004, m.sum())))
        for c in ("open", "high", "low", "close"):
            X.loc[m, c] = X.loc[m, c].to_numpy() * f
        if "volume" in X and (X["volume"] > 0).any():
            X.loc[m, "volume"] = X.loc[m, "volume"].to_numpy() * rng.lognormal(0, 0.8, m.sum())
        return X

    def redaily(D, X):
        D = D.copy()
        g = X.assign(day=X["timestamp"].dt.normalize()).groupby("day")
        agg = pd.DataFrame({"open": g["open"].first(), "high": g["high"].max(), "low": g["low"].min(), "close": g["close"].last(),
                            "volume": g["volume"].sum()})
        dd = pd.to_datetime(D["timestamp"]).dt.normalize()
        m = (dd >= t).to_numpy()
        a = agg.reindex(pd.DatetimeIndex(dd[m]))
        for c in ("open", "high", "low", "close"):
            D.loc[m, c] = a[c].to_numpy()
        if D["volume"].notna().any():
            D.loc[m, "volume"] = a["volume"].to_numpy()
        return D

    w2["daily"] = {}
    for s, X in w["intra"].items():
        X2 = pert(X)
        w2["intra"][s] = X2
        w2["daily"][s] = redaily(w["daily"][s], X2)
    for b_, d_ in (("nifty_bars", "nifty_daily"), ("bank_bars", "bank_daily"), ("it_bars", "it_daily")):
        X2 = pert(w[b_])
        w2[b_] = X2
        w2[d_] = redaily(w[d_], X2)
    return w2


DECISION = ["side", "tb", "eb", "score", "stop", "rvol", "sync", "breadth", "isync"]


def decision_rows(rows, t, s_cut):
    out = {}
    for k, T in rows.items():
        if not len(T):
            continue
        d = pd.DatetimeIndex(T["day"])
        m = (d < t) | ((d == t) & (T["tb"].to_numpy() <= s_cut))
        X = T[m].copy()
        X["symbol"] = X["symbol"].astype(str)
        out[k] = X.sort_values(["day", "symbol", "side"]).reset_index(drop=True)
    return out


def look_ahead():
    print("5. look-ahead: changing everything after the decision bar")
    w = WW.make_world(n=12, seed=9, vol_spike=0.15, exhaust=0.08, mkt_spike=0.03)
    base = pipeline(w, mgmt=False)
    cal = base["calendar"]
    tot_ok, n_rows, changed = True, 0, 0
    for j, (di, s_cut) in enumerate(((120, 20), (180, 60), (230, 95))):
        t = pd.Timestamp(cal[di])
        w2 = perturb_world(w, t, s_cut, seed=100 + j)
        alt = pipeline(w2, mgmt=False)
        a, b = decision_rows(base["rows"], t, s_cut), decision_rows(alt["rows"], t, s_cut)
        for k in set(a) | set(b):
            A, B_ = a.get(k), b.get(k)
            if A is None or B_ is None or len(A) != len(B_):
                tot_ok = False
                continue
            n_rows += len(A)
            for c in DECISION:
                if c in A and not same(A[c].to_numpy(float), B_[c].to_numpy(float), 1e-9):
                    tot_ok = False
            before = np.asarray(pd.DatetimeIndex(A["day"]) < t)
            tot_ok &= same(A.loc[before, "gross"].to_numpy(float), B_.loc[before, "gross"].to_numpy(float), 1e-9)
            on_t = np.asarray(pd.DatetimeIndex(A["day"]) == t)
            changed += int((~np.isclose(A.loc[on_t, "gross"].to_numpy(float), B_.loc[on_t, "gross"].to_numpy(float))).sum())
        later = [k for k, T in alt["rows"].items() if len(T) and (pd.DatetimeIndex(T["day"]) > t).any()]
        changed += int(len(later) > 0)
    check(tot_ok and n_rows > 1000 and changed > 0,
          f"3 cut points (day, bar): every trigger decided by then - trigger bar, entry bar, stop, score and every gate value "
          f"(participation, sector sync, breadth, BANK/IT) - is identical, and earlier days' outcomes too ({n_rows:,} rows); "
          f"the change is not empty ({changed} outcomes at the cut differ)")
    per_trigger(w, base)


def perturb_after(B, i, tb, rng):
    """A stock's (or index's) bars with session i changed after bar tb, and every later session changed."""
    B2_ = {k: v.copy() for k, v in B.items()}
    m = NB - tb - 1
    f = np.exp(np.cumsum(rng.normal(0, 0.004, m)))
    for k in ("open", "high", "low", "close"):
        B2_[k][i, tb + 1:] *= f
        B2_[k][i + 1:] *= math.exp(rng.normal(0, 0.05))
    if "volume" in B2_:
        B2_["volume"][i, tb + 1:] *= rng.lognormal(0, 0.8, m)
        B2_["volume"][i + 1:] *= rng.lognormal(0, 0.5)
    return B2_


def redaily_from(D, days, B, i):
    """The daily file with session i and every later bar session rebuilt from changed bars."""
    D = D.copy()
    dd = pd.to_datetime(D["timestamp"]).dt.normalize()
    pos = {pd.Timestamp(d): j for j, d in enumerate(dd)}
    for k in range(i, len(days)):
        j = pos.get(pd.Timestamp(days[k]))
        if j is None:
            continue
        D.loc[D.index[j], "high"] = np.nanmax(B["high"][k])
        D.loc[D.index[j], "low"] = np.nanmin(B["low"][k])
        D.loc[D.index[j], "close"] = B["close"][k][np.isfinite(B["close"][k])][-1]
        if "volume" in B and D["volume"].notna().any():
            D.loc[D.index[j], "volume"] = np.nansum(B["volume"][k])
    return D


def per_trigger(w, base, n_stock=240, n_index=36, seed=5):
    """Every sampled trigger is re-decided with ITS instrument's bars changed right after its own trigger bar (and every
    later session): trigger bar, entry bar, stop, score, participation, sector sync and breadth must not move. Then two
    planted one-bar leaks must be caught."""
    def run(label):
        rng = np.random.default_rng(seed)
        X = base["X"]
        ix = base["ix"]
        rows = base["rows"]
        bad, n = 0, 0
        stock_keys = [k for k in rows if k[0] in B2.STOCK_FAMS and len(rows[k])]
        per_key = max(1, n_stock // max(len(stock_keys), 1))
        nifty_P = {pd.Timestamp(d): ix["P"][i] for i, d in enumerate(ix["days"]) if ix["use"][i]}
        for key in stock_keys:
            T = rows[key]
            prm = dict(B2.CELLS[key[0]])[key[1]]
            for j in rng.choice(len(T), size=min(per_key, len(T)), replace=False):
                r = T.iloc[j]
                sym, day, side, tb = str(r["symbol"]), pd.Timestamp(r["day"]), int(r["side"]), int(r["tb"])
                days, B = X["bars"][sym]
                i = int(np.flatnonzero(pd.DatetimeIndex(days) == day)[0])
                F = X["feats"][sym]
                Bp = perturb_after(B, i, tb, rng)
                Fp = BM.daily_features(redaily_from(w["daily"][sym], days, Bp, i))
                out, P0 = [], None
                for FF, BB in ((F, B), (Fp, Bp)):
                    cx = B2.stock_ctx(FF, days, BB, BM.liquid_ok(FF), X["t0"])
                    sync = dict(zip((1, -1), X["mkt"].sync(X["sec"].get(sym), days, cx["P"], cx["agg_ok"])))
                    NP = np.full((len(days), NB), np.nan)
                    for k, d in enumerate(days):
                        if pd.Timestamp(d) in nifty_P:
                            NP[k] = nifty_P[pd.Timestamp(d)]
                    beta = BM.beta_series(FF, X["nd"])
                    bet = np.where(cx["trow"] >= 1, beta[np.maximum(cx["trow"] - 1, 0)], np.nan)
                    tr = B2.stock_triggers(key[0], prm, cx, NP, bet, sync)[side]
                    if P0 is None:
                        P0, mk = cx["P"][i], X["mkt"]
                    else:
                        mk = market_copy_with(X["mkt"], days[i], P0, cx["P"][i], bool(cx["agg_ok"][i]))
                    br = mk.breadth(days[i:i + 1])[0, tb]
                    out.append((tr[0][i], tr[1][i], tr[2][i], tr[3][i], cx["rv3"][i, tb], sync[side][i, tb], br))
                n += 1
                bad += int(not same(out[0], out[1], 1e-12))
        # index cells
        ikeys = [k for k in rows if k[0] in B2.INDEX_FAMS and len(rows[k])]
        per_i = max(1, n_index // max(len(ikeys), 1))
        for key in ikeys:
            T = rows[key]
            prm = dict(B2.CELLS[key[0]])[key[1]]
            for j in rng.choice(len(T), size=min(per_i, len(T)), replace=False):
                r = T.iloc[j]
                day, side, tb = pd.Timestamp(r["day"]), int(r["side"]), int(r["tb"])
                cut = day + pd.Timedelta(minutes=555 + 3 * tb)
                w2 = dict(w)
                for b_ in ("nifty_bars", "bank_bars", "it_bars"):
                    Xb = w[b_].copy()
                    m = (Xb["timestamp"] > cut).to_numpy()
                    f = np.exp(np.cumsum(rng.normal(0, 0.004, m.sum())))
                    for c in ("open", "high", "low", "close"):
                        Xb.loc[m, c] = Xb.loc[m, c].to_numpy() * f
                    w2[b_] = Xb
                ixp = B2.index_ctx(w2["nifty_bars"], X["nd"], {"NIFTY BANK": (w2["bank_bars"], dd_of(w, "bank_daily")),
                                                               "NIFTY IT": (w2["it_bars"], dd_of(w, "it_daily"))}, X["mkt"], {})
                i = int(np.flatnonzero(pd.DatetimeIndex(ix["days"]) == day)[0])
                out = []
                for I in (ix, ixp):
                    tr = B2.index_triggers(key[0], prm, I)[side]
                    out.append((tr[0][i], tr[1][i], tr[2][i], I["rv3"][i, tb], I["isync"][side][i, tb], I["state"][i] == ix["state"][i]))
                n += 1
                bad += int(not same(out[0][:5], out[1][:5], 1e-12) or not out[1][5])
        return bad, n

    bad, n = run("clean")
    check(bad == 0 and n > 200, f"{n} triggers re-decided with their own instrument changed right after the trigger bar (and every later "
                                f"session): trigger bar, entry bar, stop, score, participation, sector sync, BANK/IT, state and breadth "
                                f"unchanged in all ({bad} differ)")
    orig_trap, orig_br = B2.trap, B2.Market.breadth

    def leaky_trap(H, L, C, avg, up, dn, pc, fb, m, eu=None, ed=None):
        Cn = np.concatenate([C[:, 1:], C[:, -1:]], 1)             # the snap reads the NEXT bar's close
        return orig_trap(H, L, Cn, avg, up, dn, pc, fb, m, eu, ed)

    def leaky_breadth(self, days):
        x = orig_br(self, days)
        return np.concatenate([x[:, 1:], x[:, -1:]], 1)              # breadth read one bar late

    caught = []
    for patch in (lambda: setattr(B2, "trap", leaky_trap), lambda: setattr(B2.Market, "breadth", leaky_breadth)):
        try:
            patch()
            caught.append(run("leak")[0])
        finally:
            B2.trap, B2.Market.breadth = orig_trap, orig_br
    check(all(c > 0 for c in caught), f"planted one-bar leaks are caught: a snap reading the next bar's close ({caught[0]} triggers move), "
                                       f"breadth read one bar late ({caught[1]} move)")


def dd_of(w, k):
    X = w[k].copy()
    X["day"] = BM.SI._naive_days(X["timestamp"]).to_numpy()
    return X


def market_copy_with(mkt, day, P_old, P_new, added):
    """A copy of the market's breadth counts with one stock's session path replaced (sector counts untouched)."""
    m2 = object.__new__(B2.Market)
    m2.__dict__.update(mkt.__dict__)
    m2.b_pos, m2.b_fin = mkt.b_pos.copy(), mkt.b_fin.copy()
    di = mkt._idx([day])[0]
    if di >= 0 and added:
        m2.b_pos[di] += (P_new > 0).astype(np.int32) - (P_old > 0).astype(np.int32)
        m2.b_fin[di] += np.isfinite(P_new).astype(np.int32) - np.isfinite(P_old).astype(np.int32)
    return m2


# ----------------------------------------------------------------------
# 6. planted worlds
# ----------------------------------------------------------------------
def planted():
    print("6. planted worlds through the whole pipeline")
    t_ = time.perf_counter()
    nul = pipeline(WW.make_world(n=24, seed=31, vol_spike=0.1, mkt_spike=0.02))
    Sn = nul["selected"]
    n_win = int(Sn[Sn["pick"] == "selected"]["verdict"].isin(["PROMISING", "CHAMPION"]).sum())
    G = nul["gates"]
    M = nul["management"]
    n_add = int(G["adds"].astype(bool).sum()) + int(M[M["variant"] != "base"]["adds"].astype(bool).sum()) + int(nul["h2"]["adds"].astype(bool).sum())
    n_tests = len(G) + int((M["variant"] != "base").sum()) + len(nul["h2"])
    check(n_win == 0 and n_add == 0,
          f"NULL world: no family-side PROMISING or CHAMPION ({vtab(nul)}); none of {n_tests} gate, management and H2 tests 'adds' "
          f"(an exactly-zero lower bound plus float noise, 4e-18 bp, once passed for H2 before the strict-positive tolerance) "
          f"({time.perf_counter() - t_:.0f}s)")
    H6 = nul["h6"]
    check(not H6["holds"].any(), f"NULL world: H6 does not hold (stocks disc {H6[(H6['instrument'] != 'NIFTY 50') & (H6['window'] == 'disc')]['diff_pp'].iloc[0]:+.2f} pp)")
    mm = M[M["variant"] == "base"]
    S1_ = Sn[(Sn["pick"] == "selected") & (Sn["disc_trades"] + Sn["conf_trades"] + Sn["post_trades"].fillna(0) > 0)]
    check(mm["matches_pass1"].astype(bool).all() and len(mm) == len(S1_),
          f"pass 3 rebuilds every selected cell's time-exit book from the bars exactly as pass 1 did ({len(mm)} of {len(S1_)} cells with trades)")
    # X1 short-only and S1 long-only traps that reverse
    w = WW.make_world(n=24, seed=32, plant=[{"family": "X1", "params": {"m": 5, "level": "IB"}, "sides": (-1,), "drift": 0.010},
                                             {"family": "S1", "params": {"m": 5, "level": "OR2"}, "sides": (1,), "drift": 0.015}])
    r = pipeline(w)
    x1s, x1l, s1l, s1s = sel(r, "S", "X1"), sel(r, "L", "X1"), sel(r, "L", "S1"), sel(r, "S", "S1")
    check(wins(x1s["verdict"]) and not wins(x1l["verdict"]) and wins(s1l["verdict"]) and not wins(s1s["verdict"]),
          f"planted short-only NIFTY traps and long-only stock traps: X1-S {x1s['verdict']} ({x1s['cell']}, {x1s['disc_mean_bp']:+.1f} bp/day, "
          f"{x1s['disc_trades']} trades), X1-L {x1l['verdict']}, S1-L {s1l['verdict']} ({s1l['cell']}|N{s1l['top_n']}, "
          f"{s1l['disc_mean_bp']:+.1f}), S1-S {s1s['verdict']} (all: {vtab(r)})")
    h2 = r["h2"][(r["h2"]["side"] == "L") & (r["h2"]["family"] == "S1")].iloc[0]
    check(not h2["adds"], f"every S1 long trigger is planted alike, so the N-slot book does NOT beat the average trigger "
                          f"(H2 excess {h2['disc_excess_bp']:+.2f} [{h2['disc_excess_lo_bp']:+.2f}, {h2['disc_excess_hi_bp']:+.2f}] bp/day)")
    p1 = mgm(r, "L", "S1", "P1")
    check(p1["adds"], f"moves that keep going after the entry: P1 (add at +1R) adds {p1['disc_diff_bp']:+.2f} "
                      f"[{p1['disc_diff_lo_bp']:+.2f}, {p1['disc_diff_hi_bp']:+.2f}] bp/day, per peak exposure {p1['disc_diff_bp_pp']:+.2f}")
    ctl = r["controls"]
    c1 = ctl[(ctl["side"] == "L") & (ctl["family"] == "S1")].iloc[0]
    check(c1["disc_skill_lo_bp"] > 0 and abs(c1["flipped_share"] - 0.5) < 0.1,
          f"random-side control: the planted S1 longs show direction skill {c1['disc_skill_bp']:+.2f} [{c1['disc_skill_lo_bp']:+.2f}, "
          f"{c1['disc_skill_hi_bp']:+.2f}] bp/day; {c1['flipped_share'] * 100:.0f}% of trades flipped")
    # late coil breaks that run; late expansion after coils (H6)
    r = pipeline(WW.make_world(n=24, seed=33, plant={"family": "S3", "params": {"q": 0.2}, "drift": 0.010}))
    s3l, s3s = sel(r, "L", "S3"), sel(r, "S", "S3")
    check(wins(s3l["verdict"]) and wins(s3s["verdict"]),
          f"planted coil breaks that run: S3-L {s3l['verdict']} ({s3l['cell']}|N{s3l['top_n']}, {s3l['disc_trades']} trades), S3-S {s3s['verdict']}")
    r = pipeline(WW.make_world(n=16, seed=133, h6_plant=True), mgmt=False)
    H6 = r["h6"].set_index(["instrument", "window"])
    check(bool(H6.loc[("stocks (pooled)", "disc"), "holds"]) and bool(H6.loc[("NIFTY 50", "disc"), "holds"]),
          f"planted late expansion after coils: H6 holds for stocks ({H6.loc[('stocks (pooled)', 'disc'), 'diff_pp']:+.1f} pp "
          f"[{H6.loc[('stocks (pooled)', 'disc'), 'diff_lo_pp']:+.1f}, {H6.loc[('stocks (pooled)', 'disc'), 'diff_hi_pp']:+.1f}]) and NIFTY "
          f"({H6.loc[('NIFTY 50', 'disc'), 'diff_pp']:+.1f} pp)")
    # exhaustion fades and relative-strength leaders
    r4 = pipeline(WW.make_world(n=24, seed=34, exhaust=0.12, plant={"family": "S4", "params": {"k": 2.0}, "drift": 0.01}))
    r5 = pipeline(WW.make_world(n=24, seed=35, plant={"family": "S5", "params": {"check": 24}, "drift": 0.008}))
    s4l, s4s, s5l, s5s = sel(r4, "L", "S4"), sel(r4, "S", "S4"), sel(r5, "L", "S5"), sel(r5, "S", "S5")
    check(wins(s4l["verdict"]) and wins(s4s["verdict"]) and wins(s5l["verdict"]) and wins(s5s["verdict"]),
          f"planted exhaustion reversals: S4-L {s4l['verdict']} ({s4l['disc_trades']} trades), S4-S {s4s['verdict']}; planted 10:30 "
          f"leaders that keep going: S5-L {s5l['verdict']} ({s5l['cell']}), S5-S {s5s['verdict']}")
    # H6's realistic null: volatility clusters, so calm middays stay calm
    rc = pipeline(WW.make_world(n=24, seed=36, vol_cluster=True), mgmt=False)
    Hc = rc["h6"].set_index(["instrument", "window"])
    nwin = int(rc["selected"][rc["selected"]["pick"] == "selected"]["verdict"].isin(["PROMISING", "CHAMPION"]).sum())
    check(Hc.loc[("stocks (pooled)", "disc"), "diff_pp"] < 0 and not Hc["holds"].any() and nwin == 0,
          f"volatility clustering, nothing planted: a coil predicts FEWER late expansions "
          f"({Hc.loc[('stocks (pooled)', 'disc'), 'diff_pp']:+.1f} pp [{Hc.loc[('stocks (pooled)', 'disc'), 'diff_lo_pp']:+.1f}, "
          f"{Hc.loc[('stocks (pooled)', 'disc'), 'diff_hi_pp']:+.1f}]) - the declaration's default expectation; H6 does not hold; no family wins")
    print(f"  ({time.perf_counter() - t_:.0f}s so far)")
    # gates: the effect exists only when the condition holds
    w = WW.make_world(n=24, seed=37, plant=[{"family": "X1", "params": {"m": 5, "level": "IB"}, "sides": (-1,), "drift": 0.012,
                                              "when": "state", "else": -0.5},
                                             {"family": "S1", "params": {"m": 5, "level": "OR2"}, "sides": (1,), "drift": 0.012,
                                              "when": "sector"}])
    r = pipeline(w, mgmt=False)
    gs, gc = gate(r, "S", "X1", "state"), gate(r, "L", "S1", "sector")
    check(gs["adds"] and gc["adds"],
          f"NIFTY traps that reverse in TRAP / RANGE states (and half-continue otherwise): the state gate adds {gs['disc_diff_bp']:+.2f} "
          f"[{gs['disc_diff_lo_bp']:+.2f}, {gs['disc_diff_hi_bp']:+.2f}] bp/day (judged {gs['disc_judged_share'] * 100:.0f}%); stock traps that "
          f"reverse only when the sector agrees: the sector gate adds {gc['disc_diff_bp']:+.2f} [{gc['disc_diff_lo_bp']:+.2f}, "
          f"{gc['disc_diff_hi_bp']:+.2f}]")
    w = WW.make_world(n=24, seed=38, vol_spike=0.4, plant=[{"family": "X1", "params": {"m": 5, "level": "IB"}, "sides": (-1,), "drift": 0.012,
                                                             "when": "isync1", "else": -0.5},
                                                            {"family": "S3", "params": {"q": 0.2}, "sides": (1,), "drift": 0.03,
                                                             "when": "participation"}])
    r = pipeline(w, mgmt=False)
    gi, gp = gate(r, "S", "X1", "isync1"), gate(r, "L", "S3", "participation")
    check(gi["adds"] and gp["adds"],
          f"NIFTY traps that reverse when BANK or IT agrees with the trade: BANK/IT >= 1 adds {gi['disc_diff_bp']:+.2f} "
          f"[{gi['disc_diff_lo_bp']:+.2f}, {gi['disc_diff_hi_bp']:+.2f}]; late coil breaks that run only on >= 2x participation: "
          f"the participation gate adds {gp['disc_diff_bp']:+.2f} [{gp['disc_diff_lo_bp']:+.2f}, {gp['disc_diff_hi_bp']:+.2f}]")
    r = pipeline(WW.make_world(n=24, seed=39, plant={"family": "S1", "params": {"m": 5, "level": "OR2"}, "sides": (1,), "drift": 0.012,
                                                     "when": "breadth"}), mgmt=False)
    gb = gate(r, "L", "S1", "breadth")
    check(gb["adds"], f"stock traps that reverse only when breadth agrees: the breadth gate adds {gb['disc_diff_bp']:+.2f} "
                      f"[{gb['disc_diff_lo_bp']:+.2f}, {gb['disc_diff_hi_bp']:+.2f}]")
    # management: a fade after +1R (trailing helps, the breakeven stop protects); a shakeout (adding and moving the stop hurt)
    r = pipeline(WW.make_world(n=24, seed=40, plant={"family": "S1", "params": {"m": 5, "level": "OR2"}, "sides": (1,), "drift": 0.01,
                                                     "mode": "fade_after_1R"}))
    t1 = mgm(r, "L", "S1", "T1")
    r2 = pipeline(WW.make_world(n=24, seed=41, plant={"family": "S1", "params": {"m": 5, "level": "OR2"}, "sides": (1,), "drift": 0.01,
                                                      "mode": "shakeout"}))
    p1 = mgm(r2, "L", "S1", "P1")
    check(t1["adds"] and p1["disc_diff_hi_bp"] < 0 and not p1["adds"],
          f"moves that reach +1.2R and reverse: the EMA trail adds {t1['disc_diff_bp']:+.2f} [{t1['disc_diff_lo_bp']:+.2f}, "
          f"{t1['disc_diff_hi_bp']:+.2f}]; a shakeout through the entry before the real move: P1 hurts {p1['disc_diff_bp']:+.2f} "
          f"[{p1['disc_diff_lo_bp']:+.2f}, {p1['disc_diff_hi_bp']:+.2f}] bp/day ({time.perf_counter() - t_:.0f}s)")


# ----------------------------------------------------------------------
# 7. main() end to end
# ----------------------------------------------------------------------
def stand_ins(reconcile):
    dq = types.ModuleType("data_quality")
    dq._paths = lambda root, s: (Path(root) / f"{s}_daily.parquet", Path(root) / f"{s}_daily.ok.json")
    dq.discover_symbols = lambda root: sorted(p.name[:-len("_daily.parquet")] for p in Path(root).glob("*_daily.parquet"))
    dq._read_ok = lambda p: json.loads(Path(p).read_text(encoding="utf-8")) if Path(p).exists() else None
    ic = types.ModuleType("intraday_cache")
    ic.store, ic.BAR_MIN = (lambda root: Path(root) / "intraday_3m"), 3
    ic.DECL = {"reconcile_price_tol": 0.005, "reconcile_volume_tol": 0.10}
    ic.reconcile_symbol = reconcile
    return dq, ic


def with_modules(dq, ic, fn):
    saved = {m: sys.modules.get(m) for m in ("data_quality", "intraday_cache")}
    sys.modules.update({"data_quality": dq, "intraday_cache": ic})
    try:
        return fn()
    finally:
        for m, v in saved.items():
            if v is None:
                sys.modules.pop(m, None)
            else:
                sys.modules[m] = v


def write_root(tmp: Path, w: dict, bank=True, it=True, wrong_bank=False) -> list:
    for d in ("intraday_3m", "sectors", "panel"):
        (tmp / d).mkdir()
    syms = list(w["daily"])
    for s in syms:
        w["daily"][s].to_parquet(tmp / f"{s}_daily.parquet", index=False)
        (tmp / f"{s}_daily.ok.json").write_text(json.dumps({"series_kind": "equity"}), encoding="utf-8")
        w["intra"][s].to_parquet(tmp / "intraday_3m" / f"{s}_3m.parquet", index=False)
    for key, nm, bars in (("nifty_daily", "NIFTY50", "NIFTY 50"), ("bank_daily", "NIFTYBANK", "NIFTY BANK"), ("it_daily", "NIFTYIT", "NIFTY IT")):
        w[key].to_parquet(tmp / f"{nm}_daily.parquet", index=False)
        (tmp / f"{nm}_daily.ok.json").write_text(json.dumps({"series_kind": "index"}), encoding="utf-8")
    w["nifty_bars"].to_parquet(tmp / "intraday_3m" / "NIFTY 50_3m.parquet", index=False)
    if bank:
        (w["it_bars"] if wrong_bank else w["bank_bars"]).to_parquet(tmp / "intraday_3m" / "NIFTY BANK_3m.parquet", index=False)
    if it:
        w["it_bars"].to_parquet(tmp / "intraday_3m" / "NIFTY IT_3m.parquet", index=False)
    pd.DataFrame({"Symbol": syms, "Industry": [w["sector_of"][s] for s in syms], "ISIN Code": [f"INE{i:09d}" for i in range(len(syms))]}).to_csv(
        tmp / "sectors" / "ind_nifty500list.csv", index=False)
    return syms


def glue():
    print("7. main() end to end (stand-in modules)")
    keep = B2.CFG["discovery_start"]
    tmp = Path(tempfile.mkdtemp())
    try:
        w = WW.make_world(n=14, seed=12, vol_spike=0.1, exhaust=0.05)
        syms = write_root(tmp, w)
        for s in syms[:2]:
            (tmp / "intraday_3m" / f"{s}_3m.parquet").rename(tmp / "intraday_3m" / f"{s}_3m.parquet.bak")

        def reconcile(X, d, tp, tv):
            return pd.DataFrame({"day": pd.Series(X["timestamp"].dt.normalize().unique())}).assign(ok=True)
        dq, ic = stand_ins(reconcile)

        def body():
            B2.CFG["discovery_start"] = "2024-01-01"
            BM.CFG["discovery_start"] = "2024-01-01"
            out = {}
            with contextlib.redirect_stdout(io.StringIO()):
                out["rc0"] = B2.main(["--root", str(tmp), "--coverage-only"])
            out["missing"] = (tmp / "research2" / "bigmove2" / "missing_liquid.txt").read_text(encoding="utf-8").split()
            try:
                with contextlib.redirect_stdout(io.StringIO()):
                    B2.main(["--root", str(tmp)])
                out["refused"] = None
            except SystemExit as e:
                out["refused"] = str(e)
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                out["rc1"] = B2.main(["--root", str(tmp), "--allow-partial-universe"])
            out["log1"] = buf.getvalue()
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                out["rc2"] = B2.main(["--root", str(tmp), "--allow-partial-universe"])
            out["log2"] = buf.getvalue()
            return out
        try:
            o = with_modules(dq, ic, body)
        finally:
            BM.CFG["discovery_start"] = keep
        runs = sorted((tmp / "research2" / "bigmove2").glob("BM2_*"))
        need = ["report.md", "cells.csv", "selected.csv", "gates.csv", "management.csv", "h2.csv", "h6.csv", "states.csv", "controls.csv",
                "regimes.csv", "daily_returns.parquet", "trades_selected.parquet", "coverage.json", "summary.json", "outputs.sha256"]
        check(o["rc0"] == 0 and o["missing"] == sorted(syms[:2]) and o["refused"] is not None and "missing_liquid.txt" in o["refused"]
              and o["rc1"] == 0 and len(runs) == 2 and all((runs[0] / f).exists() for f in need),
              f"--coverage-only lists the 2 stocks without bars; the full run is refused under 90% coverage (with the way out); "
              f"--allow-partial-universe writes all {len(need)} outputs")
        summ = json.loads((runs[0] / "summary.json").read_text(encoding="utf-8"))
        rep = (runs[0] / "report.md").read_text(encoding="utf-8")
        cells = pd.read_csv(runs[0] / "cells.csv")
        import hashlib as _h
        sums = dict(reversed(line.split("  ", 1)) for line in (runs[0] / "outputs.sha256").read_text(encoding="utf-8").splitlines())
        files_ok = all(_h.sha256((runs[0] / f_).read_bytes()).hexdigest() == h_ for f_, h_ in sums.items())
        pv = summ.get("provenance", {})
        check(summ["declaration"] == _h.sha256(B2.DECL_RAW).hexdigest()[:16] and len(summ["verdicts"]) == 16 and len(cells) == 80
              and files_ok and len(sums) == len(need) - 1 and pv.get("code_sha256_16", {}).get("bigmove2_study.py") == _h.sha256(Path(B2.__file__).read_bytes()).hexdigest()[:16]
              and pv.get("v1_declaration_sha256_16") == _h.sha256(BM.DECL_RAW).hexdigest()[:16] and len(pv.get("data_fingerprint", "")) == 16
              and all(x in rep for x in ("## H6 first", "## Verdicts", "## H2", "## G2", "## G3", "## Controls", "by the day's 10:00 state",
                                         "## Limits", "Recomputation check")),
              f"summary: declaration fingerprint, 16 family-side verdicts, 80 cells; provenance (code hashes incl. v1's declaration, "
              f"data fingerprint {pv.get('data_fingerprint')}); outputs.sha256 matches all {len(sums)} files; every report section")
        led = [json.loads(x) for x in (tmp / "panel" / "research_ledger.jsonl").read_text(encoding="utf-8").splitlines()]
        rep2 = (runs[1] / "report.md").read_text(encoding="utf-8")
        summ2 = json.loads((runs[1] / "summary.json").read_text(encoding="utf-8"))
        check(len(led) == 2 and led[0]["fresh_confirmation"] and not led[1]["fresh_confirmation"] and "RERUN #2" in rep2
              and "NOT fresh evidence" in o["log2"] and summ2["provenance"]["data_fingerprint"] == pv["data_fingerprint"],
              "a second run is stamped RERUN in the report, the console and the ledger; the same data gives the same fingerprint")
        cv = summ["coverage"]
        import re as _re
        mm_ = _re.search(r"matches pass 1 in (\d+) of (\d+) cells", rep)
        check(mm_ is not None and mm_.group(1) == mm_.group(2) and int(mm_.group(2)) >= 14
              and cv["data_hygiene"]["triggered_without_exit_price"] == 0 and cv["index_sessions"]["NIFTY BANK"] >= 385
              and "(reported; the file is used)" in cv["index_note"],
              f"report: pass 3 matches pass 1 in {mm_.group(1) if mm_ else '?'} of {mm_.group(2) if mm_ else '?'} cells with trades; no trade lost "
              f"its exit price; index files checked as files (a few late sessions disagree with the daily close and are reported, not dropped): "
              f"usable sessions {cv['index_sessions']}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    # NIFTY IT's bars saved under NIFTY BANK's name (a wrong token): the price check against the daily file catches it
    tmp = Path(tempfile.mkdtemp())
    try:
        w = WW.make_world(n=10, seed=13)
        write_root(tmp, w, bank=True, it=False, wrong_bank=True)

        def reconcile(X, d, tp, tv):
            return pd.DataFrame({"day": pd.Series(X["timestamp"].dt.normalize().unique())}).assign(ok=True)
        dq, ic = stand_ins(reconcile)

        def body2():
            B2.CFG["discovery_start"] = "2024-01-01"
            BM.CFG["discovery_start"] = "2024-01-01"
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                B2.main(["--root", str(tmp), "--allow-partial-universe"])
            return buf.getvalue()
        try:
            log = with_modules(dq, ic, body2)
        finally:
            BM.CFG["discovery_start"] = keep
            B2.CFG["discovery_start"] = keep
        runs = sorted((tmp / "research2" / "bigmove2").glob("BM2_*"))
        summ = json.loads((runs[0] / "summary.json").read_text(encoding="utf-8"))
        G = pd.read_csv(runs[0] / "gates.csv")
        cv = summ["coverage"]
        nr = G[G["gate"].isin(["isync2", "isync1"])]["verdict"].astype(str)
        rec = cv["index_reconciliation"]["NIFTY BANK"]
        check("WARNING NIFTY BANK" in log and rec["failed"] == rec["checked"] and cv["index_sessions"]["NIFTY BANK"] == 0 and "NOT USED" in cv["index_note"]
              and cv["index_sessions"]["NIFTY IT"] == 0 and len(nr) and nr.str.startswith("NOT RUN").all(),
              f"NIFTY IT's bars filed as NIFTY BANK: all {rec['checked']} sessions disagree with NIFTYBANK_daily, so the FILE is not used "
              f"(a warning names the fix); without BANK and IT the BANK/IT gates are NOT RUN")
    finally:
        B2.CFG["discovery_start"] = keep
        shutil.rmtree(tmp, ignore_errors=True)


# ----------------------------------------------------------------------
# 8. selection calibration in null markets
# ----------------------------------------------------------------------
def calibration(seeds=range(51, 57)):
    print("8. selection calibration: null markets")
    for zero in (False, True):
        t_ = time.perf_counter()
        keep = (B2.COST_BPS, B2.index_cost_bp, B2.index_slip_bp, {k: B2.CFG[k] for k in ("slip_entry_bps", "slip_stop_bps", "slip_time_bps")})
        if zero:                                   # no costs at all: noise alone must rarely look like an edge
            B2.COST_BPS = 0.0
            B2.index_cost_bp = lambda sizes, entry: np.zeros(len(entry))
            B2.index_slip_bp = lambda entry: np.zeros(len(np.atleast_1d(entry)))
            for k in keep[3]:
                B2.CFG[k] = 0.0
        try:
            n_fs, n_win, n_lb, n_ps, n_g, n_gt = 0, 0, 0, 0, 0, 0
            for sd in seeds:
                r = pipeline(WW.make_world(n=20, seed=sd, vol_spike=0.1, mkt_spike=0.02), mgmt=False)
                S = r["selected"][r["selected"]["pick"] == "selected"]
                n_fs += len(S)
                n_win += int(S["verdict"].isin(["PROMISING", "CHAMPION"]).sum())
                n_lb += int((S["disc_lo_bp"] > 0).sum())
                n_ps += int(((S["disc_lo_bp"] > 0) & (S["p_search"] < 0.05)).sum())
                G = r["gates"]
                n_g += int(G["adds"].astype(bool).sum())
                n_gt += len(G)
        finally:
            B2.COST_BPS, B2.index_cost_bp, B2.index_slip_bp = keep[:3]
            B2.CFG.update(keep[3])
        label = "ZERO costs" if zero else "with costs"
        check(n_win <= max(2, int(0.05 * n_fs)) and n_g <= max(2, int(0.03 * n_gt)),
              f"{len(list(seeds))} null markets, {label}, {n_fs} family-sides: PROMISING or CHAMPION {n_win} ({n_win / n_fs * 100:.1f}%); "
              f"the selected cell's discovery lower bound above 0 in {n_lb} ({n_lb / n_fs * 100:.1f}%), also surviving the search in {n_ps}; "
              f"gates 'adding' {n_g} of {n_gt} ({time.perf_counter() - t_:.0f}s)")


def main():
    t0 = time.perf_counter()
    by_hand()
    engine_vs_loop()
    cross_check()
    fairness()
    look_ahead()
    planted()
    glue()
    calibration()
    print()
    if FAILS:
        print(f"FAILED {len(FAILS)}:")
        for f in FAILS:
            print("  - " + f)
        return 1
    print(f"VERIFIED ({B2.CODE_VERSION}) in {time.perf_counter() - t0:.0f}s")
    return 0


if __name__ == "__main__":
    sys.exit(main())
