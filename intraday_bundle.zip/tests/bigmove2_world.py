"""
tests/bigmove2_world.py - a synthetic NSE-like market for testing bigmove2_study, generated DAY BY DAY so that an effect
can be planted right after a declared rule triggers, using only what was known at that bar.

    make_world(n=40, seed=0, plant=None, h6_plant=False, vol_cluster=False, vol_spike=0.0, missing_bars=0.0, ...)

  plant        {"family": X1 | X3 | S1 | S3 | S4 | S5, "params": the cell's parameters, "sides": (1, -1),
                "drift": total move in the trade's direction from the entry to the time exit, "when": None or a
                condition at the trigger bar ("state", "sector", "participation", "breadth", "isync" (both BANK and IT
                agree), "isync1" (at least one)), "else": a drift multiplier used when the condition fails (e.g. -0.5:
                half the drift the other way; absent: nothing), "mode": "continue" (the drift) | "fade_after_1R" (the
                move reaches +1.2R, then reverses by 2.4R) | "shakeout" (+1.2R, then back 2R through the entry, then
                +3R: the move a breakeven stop gets shaken out of)} - or a LIST of such specs (index
                families are planted first, on NIFTY; then stock families). X3 / S3 plant on the coil break; S5 plants
                the top `top` RS leaders per side
  h6_plant     late-day volatility x h6_mult on coil days (the instrument's 11:00-13:00 box in its own lowest 20%)
  vol_cluster  each instrument's day-level volatility follows a persistent AR(1): calm days cluster (H6's realistic null)
  vol_spike    probability of a busy stock-day: volume x 2.5 from a random bar on
  mkt_spike    probability that a bar is a market-wide volume burst (every stock's volume x 3 in that bar)
  missing_bars probability that a stored 3-minute bar is dropped (never bar 0); the daily bars keep the full path
  exhaust      probability of a scripted exhaustion morning on a stock-day: a move of 3.5 ATR (random direction) over
               bars 0-34 on 4x volume in bars 0-14 - the only way a random walk gives S4 something to fade

Prices follow continuous paths: each bar's high and low are the exact extremes of a Brownian bridge between its open
and close, so a stop filled at its level is fair. Stocks = beta x NIFTY + sector + own noise; NIFTY BANK = 1.2 x NIFTY
+ noise, NIFTY IT = 0.8 x NIFTY + noise.

RANDOM STREAMS: every mechanism draws from its own stream (spawned from `seed`) and draws the same amount whether it is
switched on or not, so switching one effect on leaves every other random number unchanged.

The RULE DETECTORS below (l_*) are plain loops over one session's bars, written independently of the study's vectorised
code; the planting uses them, and the test suite checks they agree with the study exactly.
"""

from __future__ import annotations

import math
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

NB = 125
T_LAST = 104                       # the last bar whose close can trigger (entries up to bar 105)
XS, XI = 116, 120                  # time exits: stocks 15:03, index 15:15
OFF = pd.to_timedelta(555 + 3 * np.arange(NB), unit="m")
USHAPE = np.r_[np.linspace(1.8, 0.8, 40), np.full(45, 0.7), np.linspace(0.8, 1.4, 40)]
USHAPE = USHAPE / USHAPE.mean()
VPROF = np.r_[np.linspace(2.0, 0.35, 40), np.full(45, 0.35), np.linspace(0.35, 1.4, 40)]
VPROF = VPROF / np.sqrt(np.mean(VPROF ** 2))      # per-bar volatility profile (quiet midday); the day's variance unchanged
STREAMS = ("nifty", "index", "nbars", "sector", "cluster", "base", "volume", "bars", "missing", "exhaust")
MAXS = 8
NAN = float("nan")


def fin(x) -> bool:
    return x is not None and isinstance(x, (int, float, np.floating, np.integer)) and math.isfinite(float(x))


# ----------------------------------------------------------------------
# bars of a continuous path
# ----------------------------------------------------------------------
def bridge(o: float, rets: np.ndarray, s_bar: np.ndarray, u1: np.ndarray, u2: np.ndarray):
    """Open/high/low/close of a log-price path with per-bar returns `rets`; each bar's high and low are the exact max and
    min of a Brownian bridge (per-bar sd s_bar) between its open and close, drawn from the uniforms u1, u2 in (0, 1]."""
    lc = np.log(o) + np.cumsum(rets)
    lo_ = np.r_[np.log(o), lc[:-1]]
    s2 = np.broadcast_to(np.asarray(s_bar, float) ** 2, (NB,))
    hx = (lo_ + lc + np.sqrt((lc - lo_) ** 2 - 2 * s2 * np.log(u1))) / 2
    lx = (lo_ + lc - np.sqrt((lc - lo_) ** 2 - 2 * s2 * np.log(u2))) / 2
    return np.exp(lo_), np.exp(hx), np.exp(lx), np.exp(lc)


# ----------------------------------------------------------------------
# independent rule detectors: one session, plain loops (NaN = a missing bar)
# ----------------------------------------------------------------------
def l_vwap(H, L, C, V) -> List[float]:
    out, pv, vv = [], 0.0, 0.0
    for k in range(NB):
        tp = (H[k] + L[k] + C[k]) / 3.0
        if fin(tp) and fin(V[k]) and V[k] > 0:
            pv += tp * V[k]
            vv += V[k]
        out.append(pv / vv if vv > 0 else NAN)
    return out


def l_tp_mean(H, L, C) -> List[float]:
    out, s, n = [], 0.0, 0
    for k in range(NB):
        tp = (H[k] + L[k] + C[k]) / 3.0
        if fin(tp):
            s += tp
            n += 1
        out.append(s / n if n else NAN)
    return out


def l_ema(C, n: int) -> List[float]:
    a = 2.0 / (n + 1.0)
    out, last_c, e = [], NAN, NAN
    for k in range(NB):
        if fin(C[k]):
            last_c = C[k]
        if not fin(e):
            e = last_c
        else:
            e = a * last_c + (1 - a) * e
        out.append(e)
    return out


def l_last_close(C, upto: int) -> float:
    for k in range(upto, -1, -1):
        if fin(C[k]):
            return float(C[k])
    return NAN


def l_trap(H, L, C, avg, up, dn, pc, first_break: int, m: int, extra_up=None, extra_dn=None) -> Dict[int, tuple]:
    """{side: (snap bar, break bar, extreme)}: side -1 = the short after a failed break UP through `up`."""
    res = {}
    for side in (-1, 1):
        lv = up if side < 0 else dn
        prev, lb, out = pc, -1, (-1, -1, NAN)
        for k in range(NB):
            if k >= first_break and fin(prev) and fin(lv):
                if side < 0 and fin(H[k]) and H[k] > lv and prev <= lv:
                    lb = k
                if side > 0 and fin(L[k]) and L[k] < lv and prev >= lv:
                    lb = k
            if k <= T_LAST and lb >= 0 and k - lb <= m - 1 and fin(C[k]) and fin(lv) and fin(avg[k]):
                ok = (C[k] < lv and C[k] < avg[k]) if side < 0 else (C[k] > lv and C[k] > avg[k])
                ex = extra_up if side < 0 else extra_dn
                if ok and (ex is None or bool(ex[k])):
                    seg = [(H if side < 0 else L)[j] for j in range(lb, k + 1) if fin((H if side < 0 else L)[j])]
                    out = (k, lb, (max(seg) if side < 0 else min(seg)) if seg else NAN)
                    break
            if fin(C[k]):
                prev = C[k]
        res[side] = out
    return res


def l_pullback(H, L, b: int, pull, rv1, rev, side: int, win: int = 10):
    """(reversal bar, first pullback bar) after a break at b; the first pullback decides."""
    if b < 0:
        return -1, -1
    t = next((k for k in range(b + 1, T_LAST + 1) if pull[k]), -1)
    if t < 0:
        return -1, -1
    p, best = -1, None
    for k in range(b, t + 1):
        v = H[k] if side > 0 else L[k]
        if fin(v) and (best is None or (v > best if side > 0 else v < best)):
            p, best = k, v
    lo = p + 1 if (p >= 0 and p < t) else t
    vals = [rv1[k] for k in range(lo, t + 1) if fin(rv1[k])]
    if not vals or not (sum(vals) / len(vals) < 1.0):
        return -1, lo
    r = next((k for k in range(t + 1, min(t + win, T_LAST) + 1) if rev[k]), -1)
    return r, lo


def l_box(H, L, C) -> dict:
    hs = [H[k] for k in range(35, 75) if fin(H[k])]
    ls = [L[k] for k in range(35, 75) if fin(L[k])]
    bh, bl = (max(hs) if hs else NAN), (min(ls) if ls else NAN)
    c74 = l_last_close(C, 74)
    rngs = sorted(H[k] - L[k] for k in range(35, 75) if fin(H[k] - L[k]))
    med = (rngs[(len(rngs) - 1) // 2] + rngs[len(rngs) // 2]) / 2 if rngs else NAN
    holds = fin(bh) and fin(bl) and not any(fin(C[k]) and (C[k] > bh or C[k] < bl) for k in range(75, 80))
    return {"bh": bh, "bl": bl, "width": (bh - bl) / c74 if fin(c74) and fin(bh) else NAN, "med": med, "holds": holds}


def l_coil(H, L, C, coil_day: bool, box: dict, exp_mult: Optional[float]) -> Dict[int, tuple]:
    out = {1: (-1, NAN), -1: (-1, NAN)}
    if not (coil_day and box["holds"]):
        return out
    for side in (1, -1):
        for k in range(80, min(104, T_LAST) + 1):
            if not fin(C[k]):
                continue
            brk = C[k] > box["bh"] if side > 0 else C[k] < box["bl"]
            if exp_mult is not None:
                brk = brk and fin(H[k] - L[k]) and fin(box["med"]) and (H[k] - L[k]) >= exp_mult * box["med"]
            if brk:
                out[side] = (k, box["bl"] if side > 0 else box["bh"])
                break
    return out


def l_exhaustion(H, L, C, O0, atr, rv15, k_mult, apx, sa=0.05, move_bar=34, rv_min=3.0) -> Dict[int, tuple]:
    out = {1: (-1, NAN, NAN), -1: (-1, NAN, NAN)}
    c = l_last_close(C, move_bar)
    if not (fin(c) and fin(O0) and fin(atr) and atr > 0 and fin(rv15) and rv15 >= rv_min):
        return out
    ret = c / O0 - 1
    score = abs(ret) / atr
    for side, cond in ((-1, ret >= k_mult * atr), (1, ret <= -k_mult * atr)):
        if not cond:
            continue
        ext = -math.inf if side < 0 else math.inf
        for k in range(0, T_LAST + 1):
            if k > move_bar and k >= 1:
                if side < 0 and fin(H[k]) and H[k] > ext and fin(C[k]) and fin(L[k - 1]) and C[k] < L[k - 1]:
                    out[-1] = (k, H[k] + sa * apx, score)
                    break
                if side > 0 and fin(L[k]) and L[k] < ext and fin(C[k]) and fin(H[k - 1]) and C[k] > H[k - 1]:
                    out[1] = (k, L[k] - sa * apx, score)
                    break
            if side < 0 and fin(H[k]):
                ext = max(ext, H[k])
            if side > 0 and fin(L[k]):
                ext = min(ext, L[k])
    return out


def l_state(H, L, C, O0, pdh, pdl, sig) -> str:
    hs = [H[k] for k in range(15) if fin(H[k])]
    ls = [L[k] for k in range(15) if fin(L[k])]
    c14 = l_last_close(C, 14)
    if not (hs and ls and fin(c14) and fin(pdh) and fin(pdl) and fin(O0)):
        return "NA"
    inside = pdl <= c14 <= pdh
    if (max(hs) > pdh or min(ls) < pdl) and inside:
        return "TRAP"
    if not inside:
        return "KINETIC"
    if not fin(sig):
        return "NA"
    return "KINETIC" if abs(c14 / O0 - 1) >= sig else "RANGE"


def l_divergence(HB, LB, CB, avgB, u, d) -> tuple:
    """For one other index: per bar, (no trade above u since bar 15 and close below its average; mirror)."""
    du, dd = [], []
    mx, mn = -math.inf, math.inf
    for k in range(NB):
        if k >= 15 and fin(HB[k]):
            mx = max(mx, HB[k])
        if k >= 15 and fin(LB[k]):
            mn = min(mn, LB[k])
        du.append(fin(u) and mx <= u and fin(CB[k]) and fin(avgB[k]) and CB[k] < avgB[k])
        dd.append(fin(d) and mn >= d and fin(CB[k]) and fin(avgB[k]) and CB[k] > avgB[k])
    return du, dd


def l_rvol_row(TVhist: List[np.ndarray], tv: np.ndarray, w: int) -> np.ndarray:
    """Participation RVOL for one session from the previous sessions' turnover rows (the last 14, at least 10)."""
    def sums(x):
        x = np.where(np.isfinite(x), x, 0.0)
        cs = np.cumsum(x)
        s = cs.copy()
        s[w:] = cs[w:] - cs[:-w]
        return s
    prev = [sums(h) for h in TVhist[-14:]]
    if len(prev) < 10:
        return np.full(NB, NAN)
    m = np.mean(prev, 0)
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(m > 0, sums(tv) / m, NAN)


# ----------------------------------------------------------------------
# the world
# ----------------------------------------------------------------------
class Inst:
    """One instrument's finalised history (daily rows, turnover rows of bar days, box widths, |C14/O0 - 1|)."""

    def __init__(self):
        self.daily: List[tuple] = []
        self.tv: List[np.ndarray] = []
        self.widths: List[float] = []
        self.a14: List[float] = []
        self.lv = 0.0

    def prev(self):
        return self.daily[-1] if self.daily else None

    def atr_frac(self) -> float:
        """ATR(14) as a fraction of the close, as of the last finalised day (the study's: 14-day mean true range / close)."""
        if len(self.daily) < 15:
            return NAN
        trs = []
        for i in range(len(self.daily) - 14, len(self.daily)):
            _, o, h, l, c, v = self.daily[i]
            pc = self.daily[i - 1][4]
            trs.append(max(h - l, abs(h - pc), abs(l - pc)))
        return float(np.mean(trs) / self.daily[-1][4])

    def coil_share(self, width: float, n: int = 60, nmin: int = 40) -> float:
        h = [w for w in self.widths[-n:] if fin(w)]
        if len(h) < nmin or not fin(width):
            return NAN
        return sum(1 for w in h if w < width) / len(h)


def make_world(n: int = 40, seed: int = 0, start: str = "2023-01-02", bar_start: str = "2024-01-01", end: str = "2025-06-30",
               n_sectors: int = 4, beta: float = 0.7, sigma: float = 0.018, nsig: float = 0.009, plant: Optional[dict] = None,
               h6_plant: bool = False, h6_mult: float = 2.5, vol_cluster: bool = False, vol_spike: float = 0.0,
               missing_bars: float = 0.0, top: int = 6, exhaust: float = 0.0, mkt_spike: float = 0.0) -> dict:
    if n_sectors > MAXS:
        raise ValueError(f"at most {MAXS} sectors")
    R = {k: np.random.default_rng(c) for k, c in zip(STREAMS, np.random.SeedSequence(seed).spawn(len(STREAMS)))}
    days = pd.bdate_range(start, end)
    T = len(days)
    bstart = pd.Timestamp(bar_start)
    sq = math.sqrt(NB)
    n_ret, n_gap = R["nifty"].normal(0, 1, (T, NB)), R["nifty"].normal(0, 1, T)
    i_ret, i_gap = R["index"].normal(0, 1, (2, T, NB)), R["index"].normal(0, 1, (2, T))
    nu = 1.0 - R["nbars"].random((3, T, 2, NB))
    sec = R["sector"].normal(0, 1, (MAXS, T, NB))
    clus = R["cluster"].normal(0, 1, (n + 1, T))
    p0, vol0 = R["base"].uniform(300, 2000, n), R["base"].uniform(1e6, 3e6, n)
    gap = R["base"].normal(0, 1, (n, T))
    eps = R["base"].normal(0, 1, (n, T, NB))
    vn = R["volume"].lognormal(0, 0.3, (n, T, NB))
    spk_on, spk_k = R["volume"].random((n, T)), R["volume"].integers(0, NB, (n, T))
    mspk = R["volume"].random((T, NB))
    uu = 1.0 - R["bars"].random((n, T, 2, NB))
    miss = R["missing"].random((n + 3, T, NB))
    ex_on, ex_dir = R["exhaust"].random((n, T)), R["exhaust"].choice([-1, 1], (n, T))
    sector_of = {f"S{s:03d}": f"SEC{s % n_sectors}" for s in range(n)} if n_sectors else {}
    names = [f"S{s:03d}" for s in range(n)]
    NI, BI, II = Inst(), Inst(), Inst()
    ST = [Inst() for _ in range(n)]
    pc = {"N": 20000.0, "B": 45000.0, "I": 35000.0}
    pcs = p0.copy()
    stored: Dict[str, list] = {k: [] for k in names + ["NIFTY 50", "NIFTY BANK", "NIFTY IT"]}
    truth = []
    lr_hist: Dict[str, List[float]] = {k: [] for k in names + ["N"]}
    for d in range(T):
        on = days[d] >= bstart
        # volatility clusters (AR(1) in logs), one per instrument; drawn whether used or not
        NI.lv = 0.95 * NI.lv + 0.25 * clus[0, d]
        vmN = math.exp(NI.lv) if vol_cluster else 1.0
        sN = nsig / sq * vmN * VPROF
        rN = n_ret[d] * sN
        oN = pc["N"] * math.exp(0.002 * n_gap[d])
        rB = 1.2 * rN + 0.006 / sq * VPROF * i_ret[0, d]
        rI = 0.8 * rN + 0.007 / sq * VPROF * i_ret[1, d]
        sB = np.sqrt((1.2 * sN) ** 2 + (0.006 / sq * VPROF) ** 2)
        sI = np.sqrt((0.8 * sN) ** 2 + (0.007 / sq * VPROF) ** 2)
        oB, oI = pc["B"] * math.exp(0.002 * i_gap[0, d]), pc["I"] * math.exp(0.002 * i_gap[1, d])
        # H6 plant on NIFTY (late volatility on coil days)
        if on and h6_plant:
            bx = l_box(*bridge(oN, rN, sN, nu[0, d, 0], nu[0, d, 1])[1:])
            if fin(NI.coil_share(bx["width"])) and NI.coil_share(bx["width"]) < 0.2:
                rN = rN.copy()
                rN[80:] *= h6_mult
                sN = sN.copy()
                sN[80:] *= h6_mult
        NB_ = bridge(oN, rN, sN, nu[0, d, 0], nu[0, d, 1])
        BB_ = bridge(oB, rB, sB, nu[1, d, 0], nu[1, d, 1])
        IB_ = bridge(oI, rI, sI, nu[2, d, 0], nu[2, d, 1])
        # stocks: base paths
        S_bars, S_ret, S_sb, S_vol = [], [], [], []
        for s in range(n):
            ST[s].lv = 0.95 * ST[s].lv + 0.25 * clus[s + 1, d]
            vm = math.exp(ST[s].lv) if vol_cluster else 1.0
            se = sigma / sq * vm * VPROF
            r = beta * rN + 0.006 / sq * VPROF * sec[s % max(n_sectors, 1), d] + se * eps[s, d]
            sb = np.sqrt(se ** 2 + (beta * sN) ** 2 + (0.006 / sq * VPROF) ** 2)
            v = vol0[s] / NB * USHAPE * vn[s, d] * np.where(mspk[d] < mkt_spike, 3.0, 1.0)
            if spk_on[s, d] < vol_spike:
                v = v.copy()
                v[spk_k[s, d]:] *= 2.5
            o = pcs[s] * math.exp(0.003 * gap[s, d])
            if on and ex_on[s, d] < exhaust and fin(ST[s].atr_frac()):
                r = r.copy()
                r[:35] += ex_dir[s, d] * 3.5 * ST[s].atr_frac() / 35
                v = v.copy()
                v[:15] *= 4.0
            if on and h6_plant:
                bx = l_box(*bridge(o, r, sb, uu[s, d, 0], uu[s, d, 1])[1:])
                cs = ST[s].coil_share(bx["width"])
                if fin(cs) and cs < 0.2:
                    r = r.copy()
                    r[80:] *= h6_mult
                    sb = sb.copy()
                    sb[80:] *= h6_mult
            S_ret.append(r)
            S_sb.append(sb)
            S_vol.append(v)
            S_bars.append(bridge(o, r, sb, uu[s, d, 0], uu[s, d, 1]))
        specs = [] if plant is None else (list(plant) if isinstance(plant, (list, tuple)) else [plant])
        specs = sorted(specs, key=lambda p_: p_["family"] not in ("X1", "X3"))
        for spec in (specs if on else []):
            fam = spec["family"]
            ctxN = _nifty_ctx(NB_, NI, BB_, II, BI, IB_)
            if fam in ("X1", "X3"):
                ev = _plant_index(spec, NB_, ctxN, S_bars, sector_of, names)
                if ev is not None:
                    s_, side, R_, sgn = ev
                    rN = _apply(rN, s_, side, spec, R_, NB_[0][min(s_ + 1, NB - 1)], XI, sgn)
                    NB_ = bridge(oN, rN, sN, nu[0, d, 0], nu[0, d, 1])
                    truth.append((days[d], "NIFTY 50", fam, side, s_, sgn))
            else:
                evs = _plant_stocks(spec, S_bars, S_vol, ST, names, sector_of, NB_, NI, lr_hist, top, BB_, IB_)
                for s, (s_, side, R_, sgn) in evs.items():
                    o = S_bars[s][0][0]
                    S_ret[s] = _apply(S_ret[s], s_, side, spec, R_, S_bars[s][0][min(s_ + 1, NB - 1)], XS, sgn)
                    S_bars[s] = bridge(o, S_ret[s], S_sb[s], uu[s, d, 0], uu[s, d, 1])
                    truth.append((days[d], names[s], fam, side, s_, sgn))
        # finalise the day
        for key, inst, bars_, vol in (("N", NI, NB_, None), ("B", BI, BB_, None), ("I", II, IB_, None)):
            O, H, L, C = bars_
            inst.daily.append((days[d], O[0], H.max(), L.min(), C[-1], NAN))
            pc[key] = C[-1]
            if on:
                inst.widths.append(l_box(H, L, C)["width"])
                inst.a14.append(abs(C[14] / O[0] - 1))
        lr_hist["N"].append(math.log(NI.daily[-1][4] / NI.daily[-2][4]) if len(NI.daily) > 1 else NAN)
        for s in range(n):
            O, H, L, C = S_bars[s]
            V = S_vol[s]
            ST[s].daily.append((days[d], O[0], H.max(), L.min(), C[-1], V.sum()))
            lr_hist[names[s]].append(math.log(C[-1] / pcs[s]))
            pcs[s] = C[-1]
            if on:
                ST[s].tv.append(V * C)
                ST[s].widths.append(l_box(H, L, C)["width"])
        if on:
            for j, (nm, bars_, vol) in enumerate([(nm_, S_bars[s], S_vol[s]) for s, nm_ in enumerate(names)]
                                                 + [("NIFTY 50", NB_, None), ("NIFTY BANK", BB_, None), ("NIFTY IT", IB_, None)]):
                O, H, L, C = bars_
                keep = miss[j, d] >= missing_bars
                keep[0] = True
                stored[nm].append(pd.DataFrame({"timestamp": (days[d] + OFF)[keep], "open": O[keep], "high": H[keep], "low": L[keep],
                                                "close": C[keep], "volume": (vol[keep] if vol is not None else 0.0)}))
    daily = {nm: pd.DataFrame([r for r in ST[s].daily], columns=["timestamp", "open", "high", "low", "close", "volume"])
             for s, nm in enumerate(names)}
    idx_daily = {nm: pd.DataFrame(inst.daily, columns=["timestamp", "open", "high", "low", "close", "volume"])
                 for nm, inst in (("NIFTY 50", NI), ("NIFTY BANK", BI), ("NIFTY IT", II))}
    intra = {nm: pd.concat(v, ignore_index=True) for nm, v in stored.items()}
    return {"daily": daily, "intra": {k: intra[k] for k in names}, "nifty_daily": idx_daily["NIFTY 50"],
            "bank_daily": idx_daily["NIFTY BANK"], "it_daily": idx_daily["NIFTY IT"], "nifty_bars": intra["NIFTY 50"],
            "bank_bars": intra["NIFTY BANK"], "it_bars": intra["NIFTY IT"], "days": days, "sector_of": sector_of,
            "truth": pd.DataFrame(truth, columns=["day", "symbol", "family", "side", "trigger_bar", "sign"])}


def _apply(r: np.ndarray, s_: int, side: int, plant: dict, R_: float, entry: float, xbar: int, sgn: float = 1.0) -> np.ndarray:
    """Plant the effect on the returns AFTER the trigger bar s_ (bars <= s_ are untouched, so the trigger stands): a
    total drift in the trade's direction from the entry to the time exit ('continue'), or a move to +1R that then
    reverses by 2R ('fade_after_1R')."""
    r = r.copy()
    a, b = s_ + 1, xbar - 1
    if b < a:
        return r
    mode = plant.get("mode", "continue")
    if mode == "continue":
        r[a: b + 1] += sgn * side * plant["drift"] / (b - a + 1)
        return r
    if sgn != 1.0:
        return r
    oneR = math.log1p(R_ / entry) if fin(R_) and entry > 0 else 0.0
    n = b - a + 1
    if mode == "fade_after_1R":
        k = max(1, n // 3)
        r[a: a + k] += side * 1.2 * oneR / k
        r[a + k: b + 1] -= side * 2.4 * oneR / max(n - k, 1)
    elif mode == "shakeout":
        k = max(1, n // 4)
        r[a: a + k] += side * 1.2 * oneR / k
        r[a + k: a + 2 * k] -= side * 2.0 * oneR / k
        r[a + 2 * k: b + 1] += side * 3.0 * oneR / max(n - 2 * k, 1)
    return r


def _nifty_ctx(NB_, NI: Inst, BB_, II: Inst, BI: Inst, IB_) -> dict:
    O, H, L, C = NB_
    prev = NI.prev()
    a14 = NI.a14[-14:]
    sig = float(np.mean(a14)) if len([x for x in a14 if fin(x)]) >= 10 else NAN
    return {"pdh": prev[2] if prev else NAN, "pdl": prev[3] if prev else NAN, "pdc": prev[4] if prev else NAN, "sig": sig,
            "state": l_state(H, L, C, O[0], prev[2] if prev else NAN, prev[3] if prev else NAN, sig),
            "avg": l_tp_mean(H, L, C), "ibh": max(H[:15]), "ibl": min(L[:15]),
            "bank": BB_, "it": IB_}


def _plant_index(plant: dict, NB_, cx: dict, S_bars, sector_of, names):
    O, H, L, C = NB_
    fam, prm = plant["family"], plant["params"]
    evs = []
    if fam == "X1":
        up, dn = (cx["ibh"], cx["ibl"]) if prm["level"] == "IB" else (cx["pdh"], cx["pdl"])
        tr = l_trap(H, L, C, cx["avg"], up, dn, cx["pdc"], 15, prm["m"])
        for side, (s_, b_, ext) in tr.items():
            if s_ >= 0:
                stop = ext * (1 + 0.0002) if side < 0 else ext * (1 - 0.0002)
                evs.append((s_, side, abs(O[s_ + 1] - stop) if s_ + 1 < NB else NAN))
    elif fam == "X3":
        bx = l_box(H, L, C)
        cb = l_coil(H, L, C, fin(bx["width"]) and bx["width"] < prm["c"], bx, 2.0 if prm.get("exp") else None)
        for side, (k, stop) in cb.items():
            if k >= 0:
                evs.append((k, side, abs(O[k + 1] - stop)))
    out = []
    for e in evs:
        if e[1] not in plant.get("sides", (1, -1)):
            continue
        ok = _when(plant, cx, e[0], e[1], S_bars, sector_of, names, None, None)
        if ok or plant.get("else") is not None:
            out.append((e[0], e[1], e[2], 1.0 if ok else float(plant["else"])))
    return min(out) if out else None


def _when(plant, cxN, s_, side, S_bars, sector_of, names, sidx, rv3) -> bool:
    w = plant.get("when")
    if w is None:
        return True
    if w == "state":
        return s_ >= 14 and cxN["state"] in plant.get("states", ("TRAP", "RANGE"))
    if w in ("isync", "isync1"):
        n = 0
        for bars_ in (cxN["bank"], cxN["it"]):
            O, H, L, C = bars_
            n += int(side * (C[s_] / O[0] - 1) > 0)
        return n == 2 if w == "isync" else n >= 1
    if w == "breadth":
        ups = [bars_[3][s_] / bars_[0][0] - 1 > 0 for bars_ in S_bars]
        b = sum(ups) / len(ups)
        return b > 0.5 if side > 0 else b < 0.5
    if w == "sector":
        sec = sector_of.get(names[sidx])
        peers = [j for j, nm in enumerate(names) if j != sidx and sector_of.get(nm) == sec]
        if not peers:
            return True
        agree = [side * (S_bars[j][3][s_] / S_bars[j][0][0] - 1) > 0 for j in peers]
        return sum(agree) / len(agree) >= 0.6667 - 1e-9
    if w == "participation":
        return fin(rv3) and rv3 >= 2.0
    raise ValueError(w)


def _plant_stocks(plant: dict, S_bars, S_vol, ST: List[Inst], names, sector_of, NB_, NI: Inst, lr_hist, top: int,
                  BB_=None, IB_=None) -> dict:
    """Each stock's planted trigger (first of the day among the planted sides) -> {stock: (bar, side, R)}."""
    fam, prm = plant["family"], plant["params"]
    out = {}
    if fam == "S5":
        return _plant_s5(plant, S_bars, ST, names, sector_of, NB_, NI, lr_hist, top)
    for s in range(len(S_bars)):
        O, H, L, C = S_bars[s]
        V = S_vol[s]
        inst = ST[s]
        prev = inst.prev()
        if prev is None or len(inst.tv) < 10:
            continue
        pdh, pdl, pdc = prev[2], prev[3], prev[4]
        atr = inst.atr_frac()
        if not fin(atr):
            continue
        apx = atr * pdc
        tv = V * C
        rv1, rv3 = l_rvol_row(inst.tv, tv, 1), l_rvol_row(inst.tv, tv, 3)
        evs = []
        if fam == "S1":
            vw = l_vwap(H, L, C, V)
            if prm["level"] == "OR2":
                tr = l_trap(H, L, C, vw, max(H[:2]), min(L[:2]), NAN, 2, prm["m"])
            else:
                tr = l_trap(H, L, C, vw, pdh, pdl, pdc, 0, prm["m"])
            for side, (s_, b_, ext) in tr.items():
                if s_ >= 0:
                    stop = ext + 0.05 * apx if side < 0 else ext - 0.05 * apx
                    evs.append((s_, side, abs(O[s_ + 1] - stop), rv3[s_]))
        elif fam == "S3":
            bx = l_box(H, L, C)
            cs = inst.coil_share(bx["width"])
            for side, (k, stop) in l_coil(H, L, C, fin(cs) and cs < prm["q"], bx, None).items():
                if k >= 0:
                    evs.append((k, side, abs(O[k + 1] - stop), rv3[k]))
        elif fam == "S4":
            rv15 = l_rvol_row(inst.tv, tv, 15)[14]
            for side, (f, stop, sc) in l_exhaustion(H, L, C, O[0], atr, rv15, prm["k"], apx).items():
                if f >= 0:
                    evs.append((f, side, abs(O[f + 1] - stop), rv3[f]))
        cxs = {**_nifty_state(NB_, NI), "bank": BB_, "it": IB_}
        keep = []
        for e in evs:
            if e[1] not in plant.get("sides", (1, -1)):
                continue
            ok = _when(plant, cxs, e[0], e[1], S_bars, sector_of, names, s, e[3])
            if ok or plant.get("else") is not None:
                keep.append((e[0], e[1], e[2], 1.0 if ok else float(plant["else"])))
        if keep:
            out[s] = min(keep)
    return out


def _nifty_state(NB_, NI: Inst) -> dict:
    O, H, L, C = NB_
    prev = NI.prev()
    a14 = NI.a14[-14:]
    sig = float(np.mean(a14)) if len([x for x in a14 if fin(x)]) >= 10 else NAN
    return {"state": l_state(H, L, C, O[0], prev[2] if prev else NAN, prev[3] if prev else NAN, sig)}


def l_beta(lr_s: List[float], lr_n: List[float], w: int = 60, mp: int = 55) -> float:
    a = np.array(lr_s[-w:], float)
    b = np.array(lr_n[-w:], float)
    ok = np.isfinite(a) & np.isfinite(b)
    if ok.sum() < mp:
        return NAN
    a, b = a[ok], b[ok]
    v = b.var(ddof=1)
    return float(np.cov(a, b, ddof=1)[0, 1] / v) if v > 0 else NAN


def _plant_s5(plant, S_bars, ST, names, sector_of, NB_, NI, lr_hist, top) -> dict:
    """S5: plant continuation on the `top` strongest eligible leaders per side (RS at the check bar)."""
    c = int(plant["params"]["check"])
    On, Hn, Ln, Cn = NB_
    npc = Cn[c] / On[0] - 1
    cand = {1: [], -1: []}
    for s in range(len(S_bars)):
        O, H, L, C = S_bars[s]
        inst = ST[s]
        prev = inst.prev()
        if prev is None or len(inst.tv) < 10:
            continue
        atr = inst.atr_frac()
        b = l_beta(lr_hist[names[s]], lr_hist["N"])
        if not (fin(atr) and fin(b)):
            continue
        rs = (C[c] / O[0] - 1 - b * npc) / atr
        apx = atr * prev[4]
        sec = sector_of.get(names[s])
        peers = [j for j, nm in enumerate(names) if j != s and sector_of.get(nm) == sec]
        for side in (1, -1):
            if side * rs <= 0:
                continue
            if peers:
                sy = sum(1 for j in peers if side * (S_bars[j][3][c] / S_bars[j][0][0] - 1) > 0) / len(peers)
                if sy < 0.5:
                    continue
            stop = (min(L[: c + 1]) - 0.05 * apx) if side > 0 else (max(H[: c + 1]) + 0.05 * apx)
            cand[side].append((side * rs, s, abs(O[c + 1] - stop)))
    out = {}
    for side in plant.get("sides", (1, -1)):
        for _, s, R_ in sorted(cand[side], reverse=True)[:top]:
            if s not in out:
                out[s] = (c, side, R_, 1.0)
    return out
