@echo off
cd /d C:\Users\karanvsi\PyCharmMiscProject\bigmove_deploy
call env_daily.bat
if "%CACHE_DAILY_ROOT%"=="" (echo CACHE_DAILY_ROOT not set & exit /b 1)
echo [1/3] Index bars: NIFTY 50, NIFTY BANK, NIFTY IT
python intraday_cache.py update --root %CACHE_DAILY_ROOT% --symbols-file indices.txt
if errorlevel 1 (echo FAILED at step 1 & exit /b 1)
echo [2/3] Coverage check
python bigmove2_study.py --root %CACHE_DAILY_ROOT% --coverage-only
if errorlevel 1 (echo FAILED at step 2 & exit /b 1)
echo [3/3] BIGMOVE v2 study
python bigmove2_study.py --root %CACHE_DAILY_ROOT% --allow-partial-universe
if errorlevel 1 (echo FAILED at step 3 & exit /b 1)
echo DONE. Open the newest folder in %CACHE_DAILY_ROOT%\research2\bigmove2\ and send report.md
